{# Section tabs (quiet-orbiting-heron.md, plan item 0): switches LibraryWindow's contentMode
   ('library'/'recommended') in place, via switchTab() (library.py). Styled after
   script-plex-episodes.xml.tpl's season tabs (label/underline treatment, same font/colors,
   same Control.HasFocus()-gated label split so the bar doesn't look permanently "focused") but
   deliberately a plain type="list", not that file's type="fixedlist" center-pinned carousel -
   only ever a handful of tabs (up to 4 today: Recommended/Library, plus Collections and/or
   Categories for movie/show sections - Music/Video for Playlists instead; never enough to need
   scroll-under-a-fixed-point behavior), so a simple left-anchored list is simpler and correct
   here.

   posx=145: 45px past the usual sidebar-clearance floor used elsewhere content sits near the rail
   (100 - e.g. script-plex-recommended.xml.tpl's grouplist 50) - shifted right on request, purely
   cosmetic, not tied to any clearance requirement. Included directly into each site's real
   header body (library.xml.tpl, script-plex-recommended.xml.tpl) rather than via a block-name
   override - library.xml.tpl's own header block fully replaces default.xml.tpl's, so the
   default header_middle_add hook is never actually rendered there.

   Item cells are 200 wide (not season tabs' 170 label / 200 cell split, since fixedlist reserves
   extra room for its own scroll-under-focus peek that this plain list doesn't need) - 150 clipped
   "Recommended" under Kodi's default label truncation. Underline stays centered under the wider
   label (posx 50 = (200-100)/2, was 25 for a 150 cell).

   onleft routes to the sidebar (9000), matching every other header control's convention.
   onright reaches the audio widget (204) when it's actually on screen (Player.HasAudio, same
   condition every other onup/onright path into 204 already uses - see e.g. library_posters.
   xml.tpl's own onup pair), falling back to noop otherwise - reaching remaining/later tabs is
   via left/right within the list itself, same as season tabs. ondown's correct target differs
   by including template (grid
   content vs. hub content) - passed in via {% with tab_ondown = ... %} at each include site, not
   hardcoded here. Entry from below is via each including template's content control routing its
   own onup here first (Control.IsVisible(320) gated, falling back to its prior target when the
   tab row isn't present) - same relationship season tabs' fixedlist 205 has with the episode row's
   onup, not a sidebar onright override (sidebar's onright is hardcoded skin-wide to control/group
   50 - see script-plex-episodes.xml.tpl's own season tabs, which are entered the same way).

   Slide-right-while-sidebar-expanded animation matches every other header/content control that
   sits outside its screen's own content group 50 (see e.g. script-plex-genres.xml.tpl's
   filteropts_grouplist label) - group 50 gets this for free since it's animated directly, but
   anything in the header row (this included) needs its own copy to move with it instead of
   getting left behind under the expanded rail. #}
<control type="list" id="320">
    <!-- Hidden entirely for sections with no library-grid content at all (home_section, TYPE ==
         'mixed' - see library.py's onFirstInit(), which sets this property unconditionally on
         every swap) - nothing to switch between there, so a lone "Recommended" tab would be
         misleading UI, not just unnecessary. -->
    <visible>String.IsEmpty(Window.Property(hide.section_tabs))</visible>
    <animation effect="slide" end="220,0" time="200" tween="sine" easing="inout" condition="ControlGroup(9000).HasFocus(0)">Conditional</animation>
    <posx>145</posx>
    <posy>0</posy>
    <!-- 200px per itemlayout cell below - was 500 (room for 2.5), sized for the 2-tab case only,
         then 600 once Categories made 3 tabs possible. Collections (movie/show/artist, gated on
         an actual existence check) made 4 possible for a movie/show section with both Collections
         and Categories - 800 fits all 4; harmless slack for the still-common 2/3-tab cases, a
         type="list" control's own bounding box beyond its actual items renders nothing extra. -->
    <width>800</width>
    <height>{{ vscale(125) }}</height>
    <onleft>9000</onleft>
    <onright condition="Player.HasAudio + String.IsEmpty(Window(10000).Property(script.plex.theme_playing))">204</onright>
    <onright>noop</onright>
    <onup>noop</onup>
    <ondown>{{ tab_ondown }}</ondown>
    <orientation>horizontal</orientation>
    <itemlayout width="200" height="{{ vscale(125) }}">
        <control type="label">
            <posx>0</posx>
            <posy>0</posy>
            <width>200</width>
            <height>{{ vscale(125) }}</height>
            <font>font12</font>
            <align>center</align>
            <aligny>center</aligny>
            <textcolor>80FFFFFF</textcolor>
            <label>$INFO[ListItem.Label]</label>
        </control>
        <control type="image">
            <visible>!String.IsEmpty(ListItem.Property(current))</visible>
            <posx>50</posx>
            <posy>{{ vscale(89) }}</posy>
            <width>100</width>
            <height>2</height>
            <texture>script.plex/white-square.png</texture>
            <colordiffuse>FFE5A00D</colordiffuse>
        </control>
    </itemlayout>
    <focusedlayout width="200" height="{{ vscale(125) }}">
        <!-- Focus background, gated the same as the white-text label below (real window focus, not
             just cursor position) - same 33FFFFFF rounded pill used elsewhere for a focus highlight
             (e.g. Seasons'/Episodes' own season tabs, the summary click-target, button-row label
             overlays). Drawn first so the label/underline render on top of it. -->
        <control type="image">
            <visible>Control.HasFocus(320)</visible>
            <posx>5</posx>
            <posy>{{ vscale(37) }}</posy>
            <width>190</width>
            <height>{{ vscale(50) }}</height>
            <colordiffuse>33FFFFFF</colordiffuse>
            <texture border="10">script.plex/white-square-rounded.png</texture>
        </control>
        <control type="label">
            <visible>Control.HasFocus(320)</visible>
            <posx>0</posx>
            <posy>0</posy>
            <width>200</width>
            <height>{{ vscale(125) }}</height>
            <font>font12</font>
            <align>center</align>
            <aligny>center</aligny>
            <textcolor>FFFFFFFF</textcolor>
            <label>$INFO[ListItem.Label]</label>
        </control>
        <control type="label">
            <visible>!Control.HasFocus(320)</visible>
            <posx>0</posx>
            <posy>0</posy>
            <width>200</width>
            <height>{{ vscale(125) }}</height>
            <font>font12</font>
            <align>center</align>
            <aligny>center</aligny>
            <textcolor>80FFFFFF</textcolor>
            <label>$INFO[ListItem.Label]</label>
        </control>
        <control type="image">
            <visible>!String.IsEmpty(ListItem.Property(current))</visible>
            <posx>50</posx>
            <posy>{{ vscale(89) }}</posy>
            <width>100</width>
            <height>2</height>
            <texture>script.plex/white-square.png</texture>
            <colordiffuse>FFE5A00D</colordiffuse>
        </control>
    </focusedlayout>
</control>
