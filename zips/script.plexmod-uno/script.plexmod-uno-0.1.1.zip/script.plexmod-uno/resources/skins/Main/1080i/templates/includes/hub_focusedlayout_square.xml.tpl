<!-- Square focused layout (240x240) - uses hub_id variable. Same card recipe as
     hub_itemlayout_square.xml.tpl (see its own header comment), plus the music screens' focus
     treatment (script-plex-squares.xml.tpl's focusedlayout): 104% zoom about the art's own
     centre and a 246 ring-mask-square.png ring (240 art + the 6px ring-to-image margin the whole
     card recipe uses) tinted FFE9A20D - not the old 110% zoom / home/selected.png 9-slice border.
     The ring is still gated on Control.HasFocus (this layout renders for the selected item of
     every row, focused or not - only the focused row should show a ring). The shadow is not
     gated, matching the music screens, so a row's selected tile keeps its plate when the row
     isn't focused rather than losing it the way the poster/16:9 hub tiles do. -->
<focusedlayout width="272" condition="String.IsEqual(Window.Property(hub.display.{{ hub_id }}),square)">
    <control type="group">
        <!-- 5, not 55: compensates for the parent grouplist's posx moving from 55 to 105
             (see script-plex-recommended.xml.tpl) so this item's resting position is unchanged. -->
        <posx>5</posx>
        <!-- Always top-anchored - see hub_itemlayout_poster.xml.tpl's own matching comment for why
             peek-above's crop no longer needs a manual per-type posy override here. -->
        <!-- 52, matching hub_itemlayout_poster.xml.tpl (was 72): the same title-to-art gap on
             every row type, on request (2026-09-20). ROW_CONTENT_HEIGHT (library.py) dropped by
             the same 20 for this type. -->
        <posy>{{ vscale(52) }}</posy>
        <control type="group">
            <!-- The whole card is hidden for the row's "See more" item (is.more) - see
                 includes/hub_see_more_pill.xml.tpl, the sibling below that shows in its place. -->
            <visible>String.IsEmpty(ListItem.Property(is.more))</visible>
            <!-- 123 = the art's centre in this group's own frame (3 inset + 240/2). -->
            <animation effect="zoom" start="100" end="104" time="100" center="123,{{ vscale(123) }}" reversible="false">Focus</animation>
            <animation effect="zoom" start="104" end="100" time="100" center="123,{{ vscale(123) }}" reversible="false">UnFocus</animation>
            <posx>0</posx>
            <posy>0</posy>
            <control type="image">
                <posx>0</posx>
                <posy>0</posy>
                <width>264</width>
                <height>{{ vscale(264) }}</height>
                <texture border="24">script.plex/drop-shadow-directional.png</texture>
            </control>
            <control type="group">
                <posx>3</posx>
                <posy>3</posy>
                <control type="image">
                    <!-- See hub_itemlayout_square.xml.tpl's own copy of this control for the full
                         reasoning. -->
                    <visible>!String.IsEmpty(ListItem.Property(is.photo))</visible>
                    <posx>0</posx>
                    <posy>0</posy>
                    <width>240</width>
                    <height>{{ vscale(240) }}</height>
                    <texture diffuse="script.plex/masks/square-mask.png">script.plex/white-square.png</texture>
                    <colordiffuse>FF191B1E</colordiffuse>
                </control>
                <control type="image">
                    <!-- Native fallback= - see hub_itemlayout_square.xml.tpl's own copy for the
                         full reasoning. -->
                    <visible>String.IsEmpty(ListItem.Property(is.photo))</visible>
                    <posx>0</posx>
                    <posy>0</posy>
                    <width>240</width>
                    <height>{{ vscale(240) }}</height>
                    <texture background="true" diffuse="script.plex/masks/square-mask.png" fallback="$INFO[ListItem.Property(thumb.fallback)]">$INFO[ListItem.Thumb]</texture>
                    <aspectratio scalediffuse="false">scale</aspectratio>
                </control>
                <control type="image">
                    <visible>!String.IsEmpty(ListItem.Property(is.photo))</visible>
                    <posx>0</posx>
                    <posy>0</posy>
                    <width>240</width>
                    <height>{{ vscale(240) }}</height>
                    <texture background="true" diffuse="script.plex/masks/square-mask.png" fallback="$INFO[ListItem.Property(thumb.fallback)]">$INFO[ListItem.Thumb]</texture>
                    <aspectratio scalediffuse="false">keep</aspectratio>
                </control>
                <control type="group">
                    <!-- The poster tile's progress bar (hub_itemlayout_poster.xml.tpl), on request (2026-09-29):
                         inset 8px, 16px above the art's bottom edge, pill-masked, the same colours. -->
                    <visible>!String.IsEmpty(ListItem.Property(progress))</visible>
                    <posx>8</posx>
                    <posy>{{ vscale(224) }}</posy>
                    <control type="image">
                        <posx>0</posx>
                        <posy>0</posy>
                        <width>224</width>
                        <height>{{ vscale(8) }}</height>
                        <texture diffuse="script.plex/masks/progress-bar-mask.png">script.plex/white-square.png</texture>
                        <colordiffuse>E60A0F1A</colordiffuse>
                    </control>
                    <control type="image">
                        <posx>0</posx>
                        <posy>0</posy>
                        <width>224</width>
                        <height>{{ vscale(8) }}</height>
                        <texture diffuse="script.plex/masks/progress-bar-mask.png">$INFO[ListItem.Property(progress)]</texture>
                        <colordiffuse>FFE5A00D</colordiffuse>
                    </control>
                </control>
                <!-- hub.nolabels.<id> - see hub_itemlayout_square.xml.tpl's own copy. -->
                <control type="label">
                    <visible>String.IsEmpty(Window.Property(hub.nolabels.{{ hub_id }}))</visible>
                    <scroll>Control.HasFocus({{ hub_id }})</scroll>
                    <posx>0</posx>
                    <posy>{{ vscale(250) }}</posy>
                    <width>240</width>
                    <height>{{ vscale(35) }}</height>
                    <font>font10</font>
                    <align>center</align>
                    <textcolor>FFFFFFFF</textcolor>
                    <label>$INFO[ListItem.Label]</label>
                </control>
                <control type="label">
                    <visible>String.IsEmpty(Window.Property(hub.nolabels.{{ hub_id }})) + !String.IsEmpty(Window.Property(hub.text2lines.{{ hub_id }}))</visible>
                    <scroll>Control.HasFocus({{ hub_id }})</scroll>
                    <posx>0</posx>
                    <posy>{{ vscale(277) }}</posy>
                    <width>240</width>
                    <height>{{ vscale(35) }}</height>
                    <font>font10</font>
                    <align>center</align>
                    <!-- AAFFFFFF, not FFFFFFFF: the music grid's own second-line colour (script-plex-squares.xml.tpl's
                     album.artist label) - title bright, detail line dimmed. -->
                <textcolor>AAFFFFFF</textcolor>
                    <label>$INFO[ListItem.Label2]</label>
                </control>
            </control>
            <control type="image">
                <visible>Control.HasFocus({{ hub_id }})</visible>
                <posx>0</posx>
                <posy>0</posy>
                <width>246</width>
                <height>{{ vscale(246) }}</height>
                <texture diffuse="script.plex/masks/ring-mask-square.png">script.plex/white-square.png</texture>
                <colordiffuse>FFE9A20D</colordiffuse>
            </control>
        </control>
        {% include "includes/hub_see_more_pill.xml.tpl" with px=3 & py=98 & focused=True %}
    </control>
</focusedlayout>
