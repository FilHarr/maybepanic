# coding=utf-8
from __future__ import absolute_import

import gc
import atexit
import threading
import six
import sys
import logging
import time

try:
    from _thread import interrupt_main
except:
    from thread import interrupt_main

from kodi_six import xbmc

#import cProfile, pstats, io
#from pstats import SortKey

sys.modules['_asyncio'] = None

from . import plex
from . import localmode

from plexnet import plexapp
from plexnet.util import cleanToken
from .templating import render_templates
from .windows import background, userselect, home, library, windowutils, kodigui, busy
from . import player
from . import backgroundthread
from . import skin_check
from . import util
from .logging import KodiLogProxyHandler
from .data_cache import dcm

BACKGROUND = None
quitKodi = False
restart = False
skipEnsureLastUsed = False
# Live-confirmed (kodi.log window/dialog-ID tracing) as the actual cause of a stuck black
# screen/loading spinner after exit: updateLastUsedAddon()'s RunAddon(...)/Action(back) pair are
# both fire-and-forget builtins with no synchronization between them, opening (and meant to
# immediately back out of) Kodi's own native Programs content browser. Action(back) has no
# guarantee that browser has actually opened yet when it fires - lose that race and the browser is
# left stuck loading once it does open, with nothing left to dismiss it. A session that went
# through a full sign-out -> re-authenticate cycle involves enough extra native window churn to
# make Kodi slower to respond, making the race far more likely to be lost - confirmed reproducible
# every time; a plain exit or a user-switch (no re-auth) never lost it in testing. Rather than
# retime an already-fragile, unsynchronized builtin pair, skip this purely cosmetic feature
# (ensure_lastused - keeps the addon's position in Kodi's own addon list current) for the one
# scenario proven to trigger it, same shape as skipEnsureLastUsed's existing 'update' case.
hadReauth = False


if six.PY2:
    _Timer = threading._Timer
else:
    _Timer = threading.Timer


if util.addonSettings.debugRequests:
    # urllib3 logs each request line, query string and all - the token with it
    logger = logging.getLogger("urllib3")
    logger.addHandler(KodiLogProxyHandler(level=logging.DEBUG,
                                          log_func=lambda msg, *a, **kw: util.log(cleanToken(msg), *a,
                                                                                 prepend_msg="[urllib3]", **kw)))
    logger.setLevel(logging.DEBUG)


def waitForThreads():
    util.DEBUG_LOG('Main: Checking for any remaining threads (current: {})'.format(threading.currentThread().name))
    started = time.time()
    exit_timer_was_alive = exit_timer.is_alive()

    # if the exit timer was still alive at this point, try cancelling all threads for 5 seconds
    if not exit_timer_started or exit_timer_was_alive:
        while len(threading.enumerate()) > 1 and time.time() < started + util.addonSettings.maxShutdownWait:
            alive_threads = [t for t in list(threading.enumerate()) if t.is_alive()]
            alive_threads_out = ", ".join(t.name for t in alive_threads)
            alive_threads_count = len(alive_threads)

            # With certain linux instances we might have two threads, while Dummy is the one we're on.
            if alive_threads_count == 2 and "Dummy" in alive_threads_out and "MainThread" in alive_threads_out:
                break

            for t in threading.enumerate():
                if t != threading.currentThread():
                    if t.is_alive():
                        util.DEBUG_LOG('Main: Waiting on: {0}... (alive: {1})', t.name, alive_threads_out)
                        if isinstance(t, _Timer):
                            t.cancel()

                        try:
                            t.join(.25)
                        except:
                            util.ERROR()
            util.MONITOR.waitForAbort(0.05)
    else:
        util.DEBUG_LOG("Main: Not waiting for remaining threads as exit already took to long; hard exit")

    if time.time() >= started + util.addonSettings.maxShutdownWait or (exit_timer_started and not exit_timer_was_alive):
        util.LOG('Main: script.plexmod: threads took too long or timer hit, HARD EXITING')
        sys.exit(0)

@atexit.register
def realExit():
    xbmc.log('Main: script.plexmod: REALLY FINISHED', xbmc.LOGINFO)
    if quitKodi:
        xbmc.log('Main: script.plexmod: QUITTING KODI', xbmc.LOGINFO)
        xbmc.executebuiltin('Quit')

    elif restart:
        xbmc.executebuiltin('RunScript({})'.format(util.ADDON_ID))
    else:
        if not skipEnsureLastUsed and not hadReauth and util.getSetting('ensure_lastused'):
            updateLastUsedAddon()


def _serverWaitTimeout():
    return max(
        util.addonSettings.plextvTimeoutConnect * util.addonSettings.maxRetries1 +
        util.addonSettings.plextvTimeoutRead * util.addonSettings.maxRetries1,
        util.addonSettings.connCheckTimeout * util.addonSettings.maxRetries1)


def waitForServers():
    """Home opens once the account's servers are known: from the last run, else plex.tv's answer
    (or its failing), at most _serverWaitTimeout() - not once one of them has been picked and has
    answered, as it used to (plan Phase 9.2). Home's rows and the sidebar fill in as each server
    answers, and Home says so when none does."""
    manager = plexapp.SERVERMANAGER
    if not manager.serversKnown():
        timeout = _serverWaitTimeout()
        util.DEBUG_LOG("Main: waiting for the account's servers... (max {0} s)", timeout)
        background.setBusy()
        try:
            end = time.time() + timeout
            while not manager.serversKnown() and time.time() < end and not util.MONITOR.abortRequested():
                util.MONITOR.waitForAbort(0.1)
        finally:
            background.setBusy(False)
    util.DEBUG_LOG('Main: starting with {0} known servers', len(manager.serversByUuid))


def _awaitLocalServer(timeout):
    """Local mode's server (localmode.localServer()), waited for until one answers, at most timeout
    seconds."""
    server = localmode.localServer()
    if server:
        return server
    util.DEBUG_LOG('Main: waiting for a local server... (max {0} s)', timeout)
    background.setBusy()
    try:
        end = time.time() + timeout
        while not server and time.time() < end and not util.MONITOR.abortRequested():
            util.MONITOR.waitForAbort(0.1)
            server = localmode.localServer()
    finally:
        background.setBusy(False)
    return server


def waitForLocalServer():
    """Local mode: a server that answers, waited for (its profiles are that server's - see
    localmode.localServer()); nothing reachable - manual server entry is offered instead of silently
    landing on an empty home. It was plexnet's selected server, which is gone (plan Phase 9.3)."""
    server = _awaitLocalServer(2 * _serverWaitTimeout())
    while not server and localmode.offerServerIfNoneFound():
        plexapp.SERVERMANAGER.refreshManualConnections()
        server = _awaitLocalServer(15)
    return server


def signout():
    global hadReauth
    hadReauth = True
    util.setSetting('auth.token', '')
    # signing out always leaves local mode - staying in it would bounce us straight
    # back into an account-less local session, making the sign-out a visual no-op
    if util.getSetting('local_mode', False):
        util.setSetting('local_mode', False)
        plexapp.util.LOCAL_MODE = False
    util.DEBUG_LOG('Main: Signing out...')
    plexapp.ACCOUNT.signOut()

exit_timer_started = False

def hardExit():
    util.LOG('Main: script.plexmod: timer hit, triggering hard exit...')
    xbmc.executebuiltin('StopScript({})'.format(util.ADDON_ID))
    interrupt_main()


exit_timer = threading.Timer(util.addonSettings.maxShutdownWait, hardExit)
exit_timer.name = 'HARDEXIT-TIMER'


def stopPlaybackOnExit():
    """Stop whatever PLAYER is playing and empty Kodi's playlists, so nothing outlives the addon
    (the player_stop_on_exit setting, default on). Through PLAYER, not a bare xbmc.Player(): its
    handler then sees the stop too, and the Plex timeline gets a proper "stopped" instead of the
    server timing the session out. Before player.shutdown(), which detaches that handler. Kodi
    would otherwise keep playing - and keep the Plex play queue in its music playlist for a later
    plain Play to resume - after the UI is gone, which is what the inherited-session adoption in
    PlexPlayer.init() (player.py) exists to cope with; with this on, that's only ever reached
    after a hard kill."""
    try:
        if player.PLAYER.isPlaying():
            util.DEBUG_LOG('Main: stopping playback on exit')
            player.PLAYER.stopAndWait()
        xbmc.PlayList(xbmc.PLAYLIST_MUSIC).clear()
        xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
    except:
        util.ERROR()


def main(force_render=False):
    global BACKGROUND, skipEnsureLastUsed

    try:
        # A second attempt only when the background window's XML was broken, with the templates
        # recompiled; a third would render the same files, so a second failure ends the addon.
        # Each attempt's Cron stops before the next one starts (L2 in the navigation review).
        for attempt in range(2):
            with kodigui.GlobalProperty('rendering'):
                render_templates(force=force_render)

            if not attempt:
                # cleanup cache folder
                util.cleanupCacheFolder()

                # Once our windows are compiled (its dialogs are ours) but before any exists: switching
                # skins reloads every window Kodi has. The templates don't depend on the skin.
                try:
                    if skin_check.check():
                        # Off to update Plextuary in Kodi's add-on browser. realExit()'s RunAddon()
                        # stub and its Action(back) would back straight out of it again.
                        skipEnsureLastUsed = True
                        return
                except:
                    util.ERROR()

            errored = False
            with util.Cron(1 / util.addonSettings.tickrate):
                BACKGROUND = background.BackgroundWindow.create(function=_main)
                if BACKGROUND.waitForOpen():
                    with kodigui.GlobalProperty('running', util.ADDON_ID):
                        BACKGROUND.modal()

                        # we've had an XMLError during modalizing, rebuild templates
                        errored = BACKGROUND._errored
                        del BACKGROUND
                else:
                    util.LOG("Couldn't start main loop, exiting.")

            if not errored:
                break
            if attempt:
                util.LOG("Background window still broken after recompiling the templates, exiting.",
                         level=xbmc.LOGERROR)
            force_render = True
    finally:
        try:
            util.setGlobalProperty('ignore_spinner', '')
            util.setGlobalProperty('is_active', '')
            util.setGlobalProperty('osd_active', '')
        except:
            pass


def updateLastUsedAddon():
    """
    Runs our plugin endpoint with a stub value, so it immediately returns, then issues a Back action to back out of it.
    This is called atExit if necessary and updates the recently used video addon list with our addon (as it's a script,
    it would normally not get its lastused property updated when ran from service or script video endpoint)
    :return:
    """
    try:
        util.setGlobalProperty('ignore_spinner', '1', wait=True)
        xbmc.executebuiltin("RunAddon({},stub)".format(util.ADDON_ID))
        xbmc.executebuiltin('Action(back)')
    finally:
        util.setGlobalProperty('ignore_spinner', '')


def _main():
    global quitKodi, restart, exit_timer_started, skipEnsureLastUsed

    # uncomment to profile code #1
    #pr = cProfile.Profile()
    #pr.enable()

    util.DEBUG_LOG('[ STARTED: {0} -------------------------------------------------------------------- ]', util.ADDON.getAddonInfo('version'))
    if util.KODI_VERSION_MAJOR > 19 and util.DEBUG and util.getSetting('dump_config'):
        lv = len(util.ADDON.getAddonInfo('version'))
        util.DEBUG_LOG('[ SETTINGS DUMP {0}-------------------------------------------------------------------- '
                       ']', (lv - 4)*'-')
        util.dumpSettings()
        util.DEBUG_LOG('[ /SETTINGS DUMP {0}------------------------------------------------------------------- '
                       ']', (lv - 3) * '-')

    util.DEBUG_LOG('USER-AGENT: {0}', lambda: plex.defaultUserAgent())
    util.DEBUG_LOG('Aspect ratio: {:.2f} (default: {:.2f}), needs scaling: {}', util.CURRENT_AR, 1920 / 1080,
                   util.NEEDS_SCALING)
    background.setSplash()
    util.setGlobalProperty('is_active', '1')

    try:
        while not util.MONITOR.abortRequested():
            if plex.init(local=util.getSetting('local_mode', False)):
                background.setSplash(False)
                fromSwitch = False
                while not util.MONITOR.abortRequested():
                    if (
                        (not plexapp.ACCOUNT.isOffline or plexapp.util.LOCAL_MODE) and not
                        plexapp.ACCOUNT.isAuthenticated and
                        (len(plexapp.ACCOUNT.homeUsers) > 1 or plexapp.ACCOUNT.isProtected)

                    ):
                        oldAccID = plexapp.ACCOUNT.ID
                        result = userselect.start(BACKGROUND._winID)
                        tries = 0
                        while result == 'retry' and tries < 2:
                            util.DEBUG_LOG("Main: User select: possibly wrong pin entered, retrying after refreshing home users ({}/2)", tries + 1)
                            result = userselect.start(BACKGROUND._winID)
                            tries += 1

                        if not result:
                            return
                        elif result == 'signout':
                            signout()
                            break
                        elif result == 'signin':
                            break
                        elif result in ('cancel', 'retry') and fromSwitch:
                            if result == 'retry':
                                util.LOG("Main: User select failed multiple times possibly due to wrong pin entry.")
                            util.DEBUG_LOG('Main: User selection canceled, reusing previous user')
                            plexapp.ACCOUNT.isAuthenticated = True
                        elif result == 'cancel':
                            return
                        if not fromSwitch:
                            util.DEBUG_LOG('Main: User selected')
                        background.setBusy()
                        util.MONITOR.trigger("background.activate")

                        # store previous account ID for fast user switch
                        if oldAccID and oldAccID != plexapp.ACCOUNT.ID:
                            util.setSetting('previous_user', oldAccID)

                    closeOption = "exit"
                    try:
                        if plexapp.util.LOCAL_MODE:
                            localServer = waitForLocalServer()
                            util.DEBUG_LOG('Main: STARTING WITH SERVER: {0}', localServer)
                            # account-less local mode: offer user profiles known to the PMS
                            if not plexapp.ACCOUNT.isSignedIn and localServer:
                                localmode.seedUsersFromServer(localServer)
                        else:
                            waitForServers()

                        # LibraryWindow.open() (MultiWindow.open(), kodigui.py) is a single
                        # blocking call - construct, show, run the whole session, return only once
                        # everything's closed - unlike HomeWindow's old create()+waitForOpen()+
                        # modal() three-step. base_win_id gives it the same "did it actually become
                        # the current window" check waitForOpen() used to give this call directly;
                        # see MultiWindow._open()'s own comment for how that's implemented (reuses
                        # the first inner shell's own waitForOpen(), doesn't reimplement polling).
                        # windows=/default_window=VIEWS_RECOMMENDED are the semantically correct
                        # values for home_section anyway (its TYPE == 'mixed' forces contentMode to
                        # 'recommended' regardless - library.py's LibraryWindow.__init__), but
                        # reset() (called at the end of __init__, before this call ever blocks)
                        # recomputes both from self.section/self.contentMode unconditionally, so
                        # whatever's passed here is only needed to satisfy MultiWindow.__init__'s
                        # self._next = default_window or self._windows[0] before reset() overwrites
                        # it - not load-bearing beyond that.
                        mw = library.LibraryWindow.open(
                            base_win_id=BACKGROUND._winID,
                            section=home.home_section,
                            windows=library.VIEWS_RECOMMENDED.get('all'),
                            default_window=library.VIEWS_RECOMMENDED.get('panel'),
                        )

                        if mw._openFailed:
                            util.LOG("Couldn't open home window, exiting")
                            return

                        util.CRON.cancelReceiver(mw)

                        if not mw.closeOption or mw.closeOption in ("quit", "exit"):
                            if mw.closeOption == "quit":
                                quitKodi = True
                            return

                        closeOption = mw.closeOption

                        windowutils.shutdownHome()

                        if closeOption == 'signout':
                            signout()
                            break
                        elif closeOption == 'go_local':
                            util.DEBUG_LOG('Main: Going local...')
                            # harvest per-user tokens while plex.tv is still reachable
                            plexapp.ACCOUNT.harvestLocalUsers()
                            localmode.ensureInsecureConnectionsAllowed()
                            util.setSetting('local_mode', True)
                            break
                        elif closeOption == 'go_online':
                            util.DEBUG_LOG('Main: Going online...')
                            util.setSetting('local_mode', False)
                            break
                        elif closeOption == 'switch':
                            background.setBusy(True)
                            util.DEBUG_LOG('Main: Switching users...: {}', plexapp.ACCOUNT.ID)
                            plexapp.ACCOUNT.isAuthenticated = False
                            fromSwitch = True
                        elif isinstance(closeOption, dict):
                            if closeOption.get('fast_switch'):
                                uid = closeOption['fast_switch']
                                util.DEBUG_LOG('Main: Fast-Switching users...: {}', uid)
                                util.setSetting('previous_user', plexapp.ACCOUNT.ID)
                                # Caught here: let out, a failed switch would end the addon via
                                # main()'s outer handler. Home restarts as the current user instead.
                                try:
                                    with busy.BusySignalContext(plexapp.util.APP, "account:response", wait_max=10):
                                        if plexapp.ACCOUNT.switchHomeUser(uid, silent=True) and plexapp.ACCOUNT.switchUser:
                                            util.DEBUG_LOG('Waiting for user change...')
                                except Exception:
                                    util.ERROR('Fast user switch failed')

                        elif closeOption == 'recompile':
                            render_templates(force=True)
                            util.LOG("Restarting Home")
                            continue
                        elif closeOption == 'restart':
                            util.LOG("Restarting Addon")
                            restart = True
                            return
                        elif closeOption == 'update':
                            util.LOG("Exiting for update")
                            skipEnsureLastUsed = True
                            return
                    finally:
                        try:
                            kodiExiting = closeOption == "kodi_exit" or windowutils.HOME.closeOption == "kodi_exit"
                        except:
                            kodiExiting = False

                        if closeOption in ("quit", "exit", "restart", "update") and not kodiExiting:
                            if not exit_timer.is_alive():
                                util.DEBUG_LOG("Main: Starting hard exit timer of {} seconds...", util.addonSettings.maxShutdownWait)
                                exit_timer.start()
                            exit_timer_started = True
                        windowutils.shutdownHome()
                        BACKGROUND.activate()
                        background.setShutdown()
                        gc.collect(2)

                    if kodiExiting:
                        return

            else:
                break
    except KeyboardInterrupt:
        util.LOG("Main: Interrupted, hard exiting...")
        sys.exit(0)
    except SystemExit:
        util.LOG("Main: SystemExit exception caught (inner)...")
        return
    except:
        util.ERROR()
    finally:
        try:
            util.DEBUG_LOG('Main: SHUTTING DOWN...')
            plex.MOUSE_SETTING_CONTROL.restore()
            dcm.storeDataCache()
            plexapp.util.INTERFACE.shutdownCache()
            plexapp.util.INTERFACE.playbackManager.deinit()
            if util.getSetting('player_stop_on_exit', True):
                stopPlaybackOnExit()
            player.shutdown()
            plexapp.util.APP.preShutdown()
            util.CRON.stop()
            backgroundthread.BGThreader.shutdown()
            plexapp.util.APP.shutdown()
            waitForThreads()
            background.setBusy(False)
            background.setSplash(False)
            background.killMonitor()

            # uncomment to profile code #2
            #pr.disable()
            #sortby = SortKey.CUMULATIVE
            #s = io.StringIO()
            #ps = pstats.Stats(pr, stream=s).sort_stats(sortby)
            #ps.print_stats()
            #util.DEBUG_LOG(s.getvalue())

            util.DEBUG_LOG('FINISHED')
            util.shutdown()
            gc.collect(2)
        except SystemExit:
            util.LOG("Main: SystemExit exception caught (outer)...")
        else:
            if util.KODI_VERSION_MAJOR == 18:
                realExit()
