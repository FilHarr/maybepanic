# coding=utf-8
from __future__ import absolute_import


from kodi_six import xbmcgui

from lib import util
from lib.util import T
from plexnet import playqueue
from . import info
from . import kodigui
from . import opener
from . import pagination
from . import panel_colors
from . import preplay
from . import windowutils
from .mixins.common import CommonMixin
from .mixins.tasks import TasksMixin

# Movement actions that can land the grid selection on a paginator boundary sentinel - same set
# library.py's MOVE_SET (library.py:47-58) covers, just not imported from there (BoundedGridWindow
# deliberately doesn't depend on library.py at all).
MOVE_SET = frozenset((
    xbmcgui.ACTION_MOVE_LEFT, xbmcgui.ACTION_MOVE_RIGHT, xbmcgui.ACTION_MOVE_UP, xbmcgui.ACTION_MOVE_DOWN,
    xbmcgui.ACTION_PAGE_UP, xbmcgui.ACTION_PAGE_DOWN,
))

# THUMB_DIM matches library_grid's THUMB_POSTER_DIM - same tile markup is lifted from
# script-plex-posters.xml.tpl, so the same fetch dimensions apply.
THUMB_DIM = util.scaleResolution(268, 402)
# The home hero overlay's own big-clearlogo box (LibraryWindow.CLEAR_LOGO_DIM, library.py -
# script-plex-recommended.xml.tpl's movie/show variant): the collection info panel is that overlay
# verbatim, minus its meta row (on request, 2026-09-20). Was 616x109, the title-fallback box.
CLEAR_LOGO_DIM = util.scaleResolution(722, 162)


class BoundedGridPaginator(pagination.MCLPaginator):
    """Shared paginator shape for BoundedGridWindow's grid - one bounded fetch (getData() returns
    a real, already-populated page from the server, no chunk-cache/placeholder-then-hydrate split
    the way LibraryWindow's placeholder items and ChunkRequestTask need - see hashed-orbiting-
    pizza.md's Phase 4). CollectionWindow/SubDirWindow each just override getData()."""
    initialPageSize = 60
    pageSize = 60
    orphans = 12

    def createListItem(self, data):
        mli = super(BoundedGridPaginator, self).createListItem(data)
        self.parentWindow.setItemInfo(data, mli)
        return mli

    def prepareListItem(self, data, mli):
        self.parentWindow.setWatchedInfo(data, mli)

    def jumpToPosition(self, pos):
        """Load and select whichever page contains absolute position `pos` directly - for
        BoundedGridWindow._selectInitialItem() restoring a position beyond the initial page (see
        its own docstring). Unlike nextPage()/initialPage() (built for boundary-sentinel-triggered
        sliding, one page-worth at a time in a known direction inferred from self._direction),
        this targets an arbitrary absolute index in one fetch, centered so ordinary left/right
        scrolling from the restored position works normally afterward either way.

        Returns True if it positioned the control on a real item, False if `pos` is out of range
        or the fetch came back empty - the caller should fall back to its own default then."""
        if not (0 <= pos < self.leafCount):
            return False

        amount = self.pageSize + self.orphans
        offset = max(0, pos - amount // 2)
        if offset + amount > self.leafCount:
            offset = max(0, self.leafCount - amount)

        self.offset = offset
        self._direction = None
        data = self.getData(offset, amount)
        if not data:
            return False

        self._lastAmount = self._currentAmount
        self._currentAmount = len(data)
        self.populate(data)

        # A left-boundary sentinel occupies control index 0 whenever this page doesn't start at
        # the real beginning of the list (moreLeft, populate()'s own condition) - same "+1" shift
        # MCLPaginator.selectItem()'s own "left" branch (pagination.py) accounts for.
        relative = pos - offset + (1 if offset > 0 else 0)
        if not (0 <= relative < self.control.size()):
            return False
        self.control.selectItem(relative)
        return True


class CollectionPaginator(BoundedGridPaginator):
    def getData(self, offset, amount):
        items = self.parentWindow.collection.all(offset, amount)
        # a collection can hold episodes: their panels in their season's colours (panel_colors.py)
        panel_colors.warm(items)
        return items


class BoundedGridWindow(kodigui.ControlledWindow, windowutils.UtilMixin, windowutils.SidebarMixin,
                         CommonMixin, TasksMixin):
    """Bounded grid view for a curated/incidental set of items - a Collection's own members
    (CollectionWindow), or a folder browsed within a movie section (SubDirWindow, not yet built).

    Deliberately NOT shaped like library.py's LibraryWindow - no LibrarySettings, no sort/filter,
    no view-type toggle, no chunk-cache/placeholder items. Shaped instead like episodes.py's
    EpisodesWindow: a plain bounded content view with sidebar chrome and nothing else. See
    hashed-orbiting-pizza.md's Phase 4 for the full reasoning - this class exists because a
    collection/subDir view leans on very little of LibraryWindow beyond "show items in a grid",
    and dragging in the rest (persisted per-section settings, tab row, chunk-cache) turned out to
    be the real cost of folding these into the descendant-container work, not a design-mechanism
    gap.
    """

    # Whether a grid focus move re-seeds the window background/corner colours from the newly
    # focused item (SubDirWindow: yes, nothing else owns the screen; CollectionWindow: no).
    BACKGROUND_FOLLOWS_FOCUS = True
    path = util.ADDON.getAddonInfo('path')
    theme = 'Main'
    res = '1080i'
    width = 1920
    height = 1080

    # Real NAV_BACK dismiss, not just the flag-flip ControlledBase.close() does - same reasoning
    # as PrePlayWindow/EpisodesWindow (kodigui.ControlledWindow.onAction()'s own comment): without
    # this the window can linger on the stack and swallow input after a genuine back-out.
    dismissOnClose = True

    GRID_ID = 101
    # Click/focus target over the info panel's summary textbox (script-plex-collection.xml.tpl) -
    # same id/role as ShowWindow's/ArtistWindow's own (subitems.py). Only CollectionWindow's
    # template declares it; SubDirWindow has no info panel.
    SUMMARY_BUTTON_ID = 305
    # Play/Shuffle under the summary - again only CollectionWindow's template declares them.
    PLAY_BUTTON_ID = 301
    SHUFFLE_BUTTON_ID = 302

    def __init__(self, *args, **kwargs):
        kodigui.ControlledWindow.__init__(self, *args, **kwargs)
        TasksMixin.__init__(self)
        self.exitCommand = None
        self.parentList = kwargs.get('parent_list')

        # Sidebar entry-section persistence - same contract as every other descendant shell
        # (PrePlayWindow/EpisodesWindow/ShowWindow); resolved once here from whatever ancestor
        # passed it down, falling back to this item's own real section when this is itself a
        # genesis point. Subclasses finish this fallback (they know how to resolve their own
        # "real section") in their own __init__, after calling this one.
        self.entrySectionId = kwargs.get('entry_section_id')
        self.entryFromWatchlist = kwargs.get('entry_from_watchlist', False)

        self.gridControl = None
        self.sectionList = None
        self.paginator = None
        self.initialized = False
        self.lastItem = None
        self.lastFocusID = None

        # library.py's LibraryWindow._captureHostedShellRestoreState()/popBack() thread this
        # through when reconstructing this shell for a Back landing back on it, so setup() can
        # restore the item that was focused when a chain left here, instead of always defaulting
        # to item 0 (_selectInitialItem() below). None on every other, non-restoring construction
        # (a genuine fresh entry, or a forward swap to a different shell) - same as no kwarg
        # passed at all.
        self._restoreItemPos = kwargs.get('_restoreItemPos')

    def onFirstInit(self):
        self.gridControl = kodigui.ManagedControlList(self, self.GRID_ID, 5)
        if self.sectionList is None:
            self.sectionList = kodigui.ManagedControlList(self, self.SECTION_LIST_ID, 15)
            self.buildSectionList()
        else:
            self.sectionList.newControl(self)
        self._selectActiveSection()
        self.displayServerAndUser()
        self.setup()
        self.setBoolProperty('initialized', True)
        self.initialized = True

    def onAction(self, action):
        # Hosted: the host sees the action first (kodigui.BaseWindow.routeActionToHost()).
        if self.routeActionToHost(action):
            return
        controlID = self.getFocusId()

        if controlID == self.GRID_ID and action.getId() in MOVE_SET:
            # paginate() itself calls populate(), which fully repopulates gridControl - no
            # separate reload step needed (unlike EpisodesWindow, there's no per-item async
            # detail-refresh pass here; getData() already returns real, display-ready objects -
            # see BoundedGridPaginator).
            if self.paginator and self.paginator.boundaryHit:
                self.paginator.paginate()
            # Mirrors library.py's own MOVE_SET handling (library.py:1955-1982) - keep the
            # background/ultrablur tint in sync with whatever's actually focused, not stuck on
            # whatever setup() set it to once at open time. Not on the Collection screen
            # (BACKGROUND_FOLLOWS_FOCUS): its art and corner colours are the collection's own,
            # on request (2026-09-20), the way the hero overlay describes the collection, not
            # the focused member.
            if self.BACKGROUND_FOLLOWS_FOCUS:
                mli = self.gridControl.getSelectedItem()
                if mli and mli.dataSource is not None:
                    self.updateBackgroundFrom(mli.dataSource)
        kodigui.ControlledWindow.onAction(self, action)

    def onClick(self, controlID):
        # Not live on its host yet, or any more (kodigui.BaseWindow.ignoresInput()).
        # Hosted: the host handles the sidebar's clicks (kodigui.BaseWindow.routeClickToHost()).
        if self.routeClickToHost(controlID):
            return
        if controlID == self.GRID_ID:
            self.itemClicked()
        elif controlID == self.SUMMARY_BUTTON_ID:
            self.summaryButtonClicked()
        elif controlID in (self.PLAY_BUTTON_ID, self.SHUFFLE_BUTTON_ID):
            self.playButtonClicked(shuffle=controlID == self.SHUFFLE_BUTTON_ID)
        elif controlID == self.SECTION_LIST_ID:
            self.sectionClicked()

    def onFocus(self, controlID):
        # Not live on its host yet, or any more (kodigui.BaseWindow.ignoresInput()).
        if self.ignoresInput():
            return
        # reselectActiveSection() (SidebarMixin) snaps the highlight to the section actually on
        # screen (is.active in buildSectionList()) instead of leaving it wherever the list's
        # internal cursor last was - index 0 (Search) on a window's first focus event, which is
        # exactly what was showing up. Needs the PREVIOUS focus id, so this must read
        # self.lastFocusID before overwriting it, not after. Never wired up before now.
        self.reselectActiveSection(controlID, self.lastFocusID)
        self.lastFocusID = controlID

    def setup(self):
        raise NotImplementedError

    def summaryButtonClicked(self):
        """Full-text summary popup - the same info.showSummary() dialog every other media screen's
        summary click target opens (subitems.py/preplay.py/episodes.py). Only CollectionWindow
        gives it a control to be reached from."""
        raise NotImplementedError

    def playButtonClicked(self, shuffle=False):
        """Play/Shuffle - only CollectionWindow has the buttons."""
        raise NotImplementedError

    def createListItem(self, data):
        # Base construction only (empty label, dataSource wired up) - the paginator's own
        # createListItem() calls this via MCLPaginator.createListItem()'s default delegation
        # (pagination.py:48-49), then immediately calls setItemInfo() to fill in the rest. Mirrors
        # EpisodesWindow.createListItem() (episodes.py:1727-1731)'s identical split.
        return kodigui.ManagedListItem('', data_source=data)

    # The poster's (THUMB_DIM); SubDirAr16x9Window's the 16:9 card's
    THUMB_DIM = THUMB_DIM

    def thumbFor(self, data):
        if data.TYPE == 'collection':
            # Collections often have no own poster - fall back to a composite of member posters,
            # same as library.py's _chunkCallback() (library.py:4071-4076) and the dead-code
            # createCollectionListItem() (library.py:5291-5294) both already do.
            return data.artCompositeURL(*self.THUMB_DIM)
        return data.defaultThumb.asTranscodedImageURL(*self.THUMB_DIM)

    def setItemInfo(self, data, mli):
        # Shared by CollectionWindow and SubDirWindow - genuinely generic, not collection-specific:
        # handles the same movie/show/nested-collection/plain-directory mix either shell's grid can
        # contain. defaultTitle/defaultThumb/defaultArt are all base PlexObject-level fallbacks
        # (plexobjects.py), so this works unchanged for a Generic/TYPE=='Directory' folder entry too.
        # Only what the templates read (the navigation review's step 12 follow-ups, checked by
        # tests/test_grid_item_properties.py): no per-item summary or art, which neither screen
        # reads. Each write is a GUI call.
        mli.setLabel(data.defaultTitle)
        # Second caption line under the poster (script-plex-collection.xml.tpl's 'year' label, the
        # library grid's own - on request, 2026-09-20). Plain year only: the grid's sort-key
        # subDisplay variants don't apply here, there's no sort. Nested collections/folders
        # carry no year, so theirs stays a single line.
        mli.setProperty('year', data.TYPE != 'collection' and data.get('year') or '')
        mli.setThumbnailImage(self.thumbFor(data))
        if not data.isDirectory() and data.get('duration').asInt():
            mli.setLabel2(util.durationToText(data.fixedDuration()))

    def setWatchedInfo(self, data, mli):
        # Mirrors library.py's _chunkCallback() generic-item branch (library.py:4098-4105) -
        # proven-correct shape for the same heterogeneous movie/show/directory mix, minus the
        # LibraryWindow-specific sort-column/chunk-cache bits. TYPE == 'Directory' (the class-level
        # type, matching production exactly), NOT isDirectory() (the tag-name-based method) - shows
        # and seasons are also tag-shaped like a Directory in Plex's API (they're containers, not
        # playable items) but have a real registered TYPE ('show'/'season') and DO want a badge via
        # the unwatched.count branch below - isDirectory() was wrongly excluding them entirely.
        # Live-confirmed: this class of bug is exactly what silently broke show-clicking too, see
        # itemClicked()'s own note.
        if data.TYPE == 'Directory':
            return
        if not data.isPlayed:
            if data.TYPE == 'show' or data.TYPE == 'season':
                # No .asInt() here - unlike Episode's unViewedLeafCount (PlexValue, episodes.py:120
                # calls .asInt() on it), Show/Season's is a plain Python int already - live-confirmed
                # via a real AttributeError doing exactly what episodes.py's pattern does. Matches
                # library.py's own identical show/season branch (library.py:4101) exactly, which
                # never called .asInt() here either - should have just copied that directly instead
                # of borrowing episodes.py's shape for a different underlying type.
                mli.setProperty('unwatched.count', str(data.unViewedLeafCount))
                mli.setBoolProperty('unwatched.count.large', data.unViewedLeafCount > 999)
        elif data.isPlayed:
            mli.setBoolProperty('watched', '1')
        mli.setProperty('progress', util.getProgressImage(data))

    def itemClicked(self):
        """Scoped version of library.py's showPanelClicked() dispatch (library.py:3366-3482) -
        only the four cases actually reachable from inside a collection/subDir: a real movie/show,
        another (nested) collection, or (SubDirWindow only) another folder. Not photo/artist/
        album/track/playlists - those aren't reachable from a folder-browsed movie section or a
        movie/show collection in practice; see the plan's own note on this assumption."""
        mli = self.gridControl.getSelectedItem()
        if not mli or mli.dataSource is None:
            return

        data = mli.dataSource
        extra_kwargs = {
            'entry_section_id': self.entrySectionId,
            'entry_from_watchlist': self.entryFromWatchlist,
        }

        # TYPE checks first, isDirectory() (tag-shape, not class-level type) last - live-confirmed
        # bug: shows come back from Plex's API as <Directory type="show">, so isDirectory() is
        # True for them too. Checking it before TYPE == 'show' meant every show silently matched
        # the directory branch (openDirectory(), a no-op stub reserved for SubDirWindow) instead -
        # nothing opened, nothing threw, so nothing logged either. library.py's own
        # showPanelClicked() already gets this ordering right (library.py:3420-3429) - isDirectory()
        # only ever gets checked *inside* the movie-type branch there, after collection/show/season/
        # episode have already been ruled out, which is what makes it safe to use as a fallback.
        if data.TYPE == 'collection':
            self.openWindow(CollectionWindow, collection=data, **extra_kwargs)
        elif data.TYPE == 'show':
            # self.openItem() (opener.open() -> opener.showClicked(), context=self), not a direct
            # self.openWindow(subitems.ShowWindow, ...) - see library.py's own showPanelClicked()
            # comment (identical fix, same live-confirmed skipChildren-bypass gap) for why.
            self.openItem(data, parent_list=self.gridControl, **extra_kwargs)
        elif data.isDirectory():
            self.openDirectory(data, extra_kwargs)
        else:
            self.openWindow(preplay.PrePlayWindow, video=data, parent_list=self.gridControl,
                            **extra_kwargs)

    def _selectInitialItem(self):
        """Shared tail of both CollectionWindow.setup() and SubDirWindow.setup(), called right
        after self.paginator.paginate()'s initial-page load: selects self._restoreItemPos
        (an *absolute* list position - library.py's _captureHostedShellRestoreState()) when
        there's a valid one pending, otherwise item 0 - the plain, always-item-0 behavior both had
        before this existed.

        self.paginator._currentAmount (set by the paginate() call that always immediately
        precedes this) is the real item count on the just-loaded initial page (offset always 0
        here, so a control-relative index and an absolute one are the same thing), excluding the
        right-boundary sentinel MLI populate() may have appended - selecting that sentinel instead
        of a real item would be a real, if harmless-looking, bug (it's a focusable `is.boundary`
        item, not the grid item the position was actually captured against).

        A position beyond that initial page (live-reported, 2026-09-03: "put back to item 0" for
        anything only reached by scrolling the paginator further) falls to
        BoundedGridPaginator.jumpToPosition() instead - a direct, one-fetch jump to whichever page
        actually contains it, rather than the cheap in-page select above. Only once *that* also
        fails (position no longer exists at all, e.g. the collection changed) does this fall back
        to item 0, same as always."""
        pos = self._restoreItemPos
        if pos is not None and 0 <= pos < self.paginator._currentAmount:
            self.gridControl.selectItem(pos)
        elif pos is not None and self.paginator.jumpToPosition(pos):
            pass
        else:
            self.gridControl.selectItem(0)

    def openDirectory(self, data, extra_kwargs):
        """Hook: only SubDirWindow (see its own override below) needs to open a further subfolder -
        a CollectionWindow's own members should never themselves be plain directories. Left as a
        no-op here rather than NotImplementedError, since reaching this from a real collection
        would indicate unexpected server data, not a programming error."""
        pass



class CollectionWindow(BoundedGridWindow):
    xmlFile = 'script-plex-collection.xml'
    # The background art/corner colours stay the collection's own (setup()) rather than
    # following the focused member - see BoundedGridWindow.onAction().
    BACKGROUND_FOLLOWS_FOCUS = False

    def __init__(self, *args, **kwargs):
        BoundedGridWindow.__init__(self, *args, **kwargs)
        self.collection = kwargs.get('collection')
        if self.entrySectionId is None and not self.entryFromWatchlist:
            self.entrySectionId = self.collection.getLibrarySectionId()

    def backgroundItem(self):
        # The collection's own art from the first frame (kodigui's paintInitialBackground()),
        # the same as setup() paints.
        return self.collection

    def summaryButtonClicked(self):
        # The full text, off the object - the collection.summary property only ever holds the
        # capped display copy (util.summaryForBox()).
        info.showSummary(self.collection.title, self.collection.get('summary'))

    def playButtonClicked(self, shuffle=False):
        """The whole collection as a server play queue, in the collection's own order or shuffled -
        the way Plex's own clients play one. The queue is the collection's children listing
        (library://<section>/directory//library/collections/<id>/children); PMS expands a show
        collection into its episodes itself (checked live, 2026-09-30: a one-show collection gave
        a 12-episode queue)."""
        pq = playqueue.createPlayQueueForItem(self.collection, options={'shuffle': shuffle})
        if not pq:
            util.DEBUG_LOG('CollectionWindow: no play queue for {}', self.collection)
            return
        self.processCommand(opener.open(pq, context=self))

    def metaLine(self, count):
        """"<n> items" plus, after a bullet, the members' year span "minYear-maxYear" - only when
        it is a span: a single-year collection (live: a one-show TV collection reports
        minYear == maxYear) shows just the count, no bullet, no year (on request, 2026-09-20).
        minYear/maxYear come with the collection on every path that reaches this window (the
        library grid's /all?type=18 listing, verified the same day)."""
        parts = [T(35055, '{0} items').format(count)]
        min_year = self.collection.get('minYear')
        max_year = self.collection.get('maxYear')
        if min_year and max_year and min_year != max_year:
            parts.append(u'{0}-{1}'.format(min_year, max_year))
        return u' \u2022 '.join(parts)

    def setup(self):
        # summary/childCount read via .get() (raw XML attribute access, PlexValue-wrapped), same
        # convention library.py's _chunkCallback() uses for the same kind of field - live-confirmed
        # against a real server response (2026-08-24): both populate correctly.
        self.setProperty('collection.title', self.collection.title)
        self.setProperty('collection.summary', util.summaryForBox(self.collection.get('summary')))
        # Same clearlogo-with-title-fallback pattern as PrePlayWindow/EpisodesWindow - the template
        # shows whichever of the two sibling controls matches whether this property is empty, not
        # a Python-side branch. util.clearLogoFrom() itself already returns '' safely when the
        # collection has no clearLogo field at all (most won't - see its own docstring).
        self.setProperty('clear.logo', util.clearLogoFrom(self.collection, *CLEAR_LOGO_DIM))

        self.updateBackgroundFrom(self.collection)
        # No art on this collection (live: 6 of 106 movie collections): hide the hero art box
        # (default_background.xml.tpl reads hero.no_art, the same gate Home uses for playlists)
        # rather than leave it showing windowSetBackground(None)'s black fallback over a ghost of
        # whatever art the previous screen last showed. The corner panel above it still tints
        # from the collection's own ultraBlurColors. Set once - BACKGROUND_FOLLOWS_FOCUS is False
        # here, so nothing later would repopulate the box anyway.
        self.setBoolProperty('hero.no_art', not self.collection.get('art'))

        leafCount = self.collection.get('childCount').asInt()
        self.setProperty('collection.meta', self.metaLine(leafCount))
        # Play/Shuffle only for a collection there's a queue for: something in it, of a type a
        # play queue can be made from (playqueue.PlayQueueFactory - video or audio here).
        self.setBoolProperty('collection.playable',
                             leafCount > 0 and bool(playqueue.PlayQueueFactory().getContentType(self.collection)))

        self.paginator = CollectionPaginator(self.gridControl, parent_window=self, leaf_count=leafCount)
        self.paginator.paginate()
        self._selectInitialItem()
        # Explicit, not relied on via XML <defaultcontrol> - default.xml.tpl's own window-level
        # defaultcontrol (default.xml.tpl:12, the header Home button) wins over a nested one
        # declared on a content group, same reason episodes.py's own template has an abandoned,
        # commented-out attempt at exactly this (script-plex-episodes.xml.tpl:39). Mirrors
        # library.py's doRefill()/fill() doing the identical self.setFocusId(POSTERS_PANEL_ID)
        # after populating its own grid (library.py:3683-3684).
        self.setFocusId(self.GRID_ID)


def buildSubDirSection(section, datasource):
    """Synthetic, folder-scoped section for one directory click - identical construction to what
    library.py's showPanelClicked() used to build inline before SubDirWindow existed. `section` is
    whatever section this folder was reached from (a real section for the first hop out of a real
    LibraryWindow, or an already-synthetic one when SubDirWindow.openDirectory() drills further);
    `datasource` is the clicked Directory item whose own key becomes the new section's key. Shared
    so both callers build the exact same shape rather than keeping two copies in sync - see
    hashed-orbiting-pizza.md's Phase 4 "SubDirWindow" notes.
    """
    cls = section.__class__
    newSection = cls(section.data, section.initpath, section.server, section.container)
    sectionId = newSection.key
    if not sectionId.isdigit():
        sectionId = newSection.getLibrarySectionId()
    newSection.set('librarySectionID', sectionId)
    newSection.key = datasource.key
    newSection.title = datasource.title
    return newSection


class SubDirPaginator(BoundedGridPaginator):
    def getData(self, offset, amount):
        items = self.parentWindow.section.folder(offset, amount, subDir=True)
        panel_colors.warm(items)
        return items


class SubDirWindow(BoundedGridWindow):
    xmlFile = 'script-plex-subdir.xml'

    def __init__(self, *args, **kwargs):
        BoundedGridWindow.__init__(self, *args, **kwargs)
        self.section = kwargs.get('section')
        if self.entrySectionId is None and not self.entryFromWatchlist:
            self.entrySectionId = self.section.getLibrarySectionId()

    def setup(self):
        # No info panel/title - a subDir folder has no comparable metadata to a Collection's
        # summary/childCount/clearLogo, per the plan's own decision on this.
        leafCount = self.section.folder(0, 0, subDir=True).totalSize.asInt()

        self.paginator = SubDirPaginator(self.gridControl, parent_window=self, leaf_count=leafCount)
        self.paginator.paginate()
        self._selectInitialItem()
        # Same explicit-focus requirement as CollectionWindow.setup() - see its own comment for why
        # the XML <defaultcontrol> alone doesn't reliably win initial window focus here.
        self.setFocusId(self.GRID_ID)

        # No single owning item to seed the background from (unlike CollectionWindow's own
        # self.collection) - seed it from whatever the grid's own initial selection turned out to
        # be instead, same as the MOVE_SET re-tint BoundedGridWindow.onAction() already does on
        # every subsequent focus change.
        mli = self.gridControl.getSelectedItem()
        if mli and mli.dataSource is not None:
            self.updateBackgroundFrom(mli.dataSource)

    def openDirectory(self, data, extra_kwargs):
        self.openWindow(subDirWindowFor(self.section), section=buildSubDirSection(self.section, data),
                        **extra_kwargs)


class SubDirAr16x9Window(SubDirWindow):
    """A folder of an Other Videos section: its library grid's 16:9 tile (library.Ar16x9Window),
    three to a row (script-plex-subdir-ar16x9.xml.tpl), on request (2026-10-09)."""
    xmlFile = 'script-plex-subdir-ar16x9.xml'
    # The library grid's (library_grid.THUMB_AR16X9_DIM)
    THUMB_DIM = util.scaleResolution(512, 288)

    def thumbFor(self, data):
        if data.TYPE == 'movie':
            # its art, as the library grid shows it - or its thumb, a frame too, without: an empty
            # path never falls back (util.standInThumb())
            return (data.defaultArt or data.defaultThumb).asTranscodedImageURL(*self.THUMB_DIM)
        return SubDirWindow.thumbFor(self, data)


def subDirWindowFor(section):
    """The folder screen for a folder of this section: Other Videos' 16:9 one, or the poster one."""
    from .library_grid import isOtherVideos
    return SubDirAr16x9Window if isOtherVideos(section) else SubDirWindow
