# coding=utf-8
from lib import util
from lib.i18n import T
from lib.windows import kodigui


class SeasonsMixin(object):
    SEASONS_CONTROL_ATTR = "subItemListControl"

    THUMB_DIMS = {
        'show': {
            'main.thumb': util.scaleResolution(347, 518),
            'item.thumb': util.scaleResolution(240, 360)
        },
        'episode': {
            'main.thumb': util.scaleResolution(347, 518),
            'item.thumb': util.scaleResolution(198, 295)
        },
        'artist': {
            'main.thumb': util.scaleResolution(519, 519),
            # 240x240 = the artist screen's own drawn album-tile size exactly
            # (includes/artist_album_row.xml.tpl) - was 215, which the skin then upscaled.
            'item.thumb': util.scaleResolution(240, 240)
        }
    }

    def _createListItem(self, mediaItem, obj):
        mli = kodigui.ManagedListItem(
            obj.title or '',
            thumbnailImage=obj.defaultThumb.asTranscodedImageURL(*self.THUMB_DIMS[mediaItem.type]['item.thumb']),
            data_source=obj
        )
        episode_count = obj.leafCount.asInt()
        episode_str = T(35057, '{} episode') if episode_count == 1 else T(35056, '{} episodes')
        mli.setProperty('episode.count', episode_str.format(episode_count))
        return mli

    def fillSeasons(self, show, update=False, seasonsFilter=None, selectSeason=None, do_focus=True,
                     extraFirstItem=None, seasons=None):
        if seasons is None:
            try:
                seasons = show.seasons()
            except:
                raise util.NoDataException

        if not seasons or (seasonsFilter and not seasonsFilter(seasons)):
            return False

        items = []
        idx = 0
        focus = None
        current_idx = None

        # Episodes' own season-tab row (EpisodesWindow.SEASONS_LIST_ID) prepends a pinned "Show" entry
        # ahead of the real seasons - see episodes.py's own fillSeasons() call sites. ShowWindow's own
        # season row never passes this, so its behavior is unchanged.
        if extraFirstItem is not None:
            items.append(extraFirstItem)
            idx = 1
        for season in seasons:
            mli = self._createListItem(show, season)
            if mli:
                is_current = bool(selectSeason) and season == selectSeason
                mli.setProperty('index', str(idx))
                mli.setProperty('thumb.fallback', 'script.plex/thumb_fallbacks/show.png')
                mli.setBoolProperty('current', is_current)
                if is_current:
                    current_idx = idx
                seasonWatched = season.isWatched
                has_ondeck_progress = False
                for v in show.onDeck:
                    if v.parentRatingKey == season.ratingKey and v.viewOffset.asInt():
                        has_ondeck_progress = True
                        break
                if has_ondeck_progress and season.viewedLeafCount == season.leafCount:
                    seasonWatched = False
                # The tick and count follow Plex's "played" (season.isPlayed - every episode played),
                # not seasonWatched: a re-watch in progress keeps the tick, as the official client
                # does - only Mark Unplayed takes it away (on request, 2026-10-02). seasonWatched's
                # on-deck override above now only decides which season the row focuses on. It used
                # to drop the tick for the on-deck re-watch only - one season per show, since Plex
                # keeps one on-deck episode per show - and showed a "0" count in its place.
                played = season.isPlayed
                show_count = not played and season.unViewedLeafCount > 0
                mli.setProperty('unwatched.count', show_count and str(season.unViewedLeafCount) or '')
                mli.setBoolProperty('unwatched.count.large', show_count and season.unViewedLeafCount > 999)
                mli.setBoolProperty('watched', played)
                # Which season the row lands on when the caller didn't name one: the first
                # non-Specials season that isn't fully watched. `focus is None` latches it, so only
                # the first match counts. This used to give that same season a progress bar on its
                # poster as well - dropped on request, see script-plex-seasons.xml.tpl for why.
                if not selectSeason and not seasonWatched and focus is None and season.index.asInt() > 0:
                    focus = idx
                items.append(mli)
                idx += 1

        subItemListControl = getattr(self, self.SEASONS_CONTROL_ATTR)
        if update:
            subItemListControl.replaceItems(items)
        else:
            subItemListControl.reset()
            subItemListControl.addItems(items)

        if do_focus:
            if selectSeason:
                if current_idx is not None:
                    subItemListControl.setSelectedItemByPos(current_idx)
            elif focus is not None:
                subItemListControl.setSelectedItemByPos(focus)

        return True
