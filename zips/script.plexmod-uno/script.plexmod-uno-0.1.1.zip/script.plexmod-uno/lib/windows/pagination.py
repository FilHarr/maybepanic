from __future__ import absolute_import

from kodi_six import xbmcgui

from lib import util
from lib.util import T
from . import kodigui

# A poster row's items before its "See more" tile (RowMaxMixin) - the hub rows' own number
# (home.HUB_ROW_MAX_ITEMS)
ROW_MAX = 20


class MCLPaginator(object):
    """
    A paginator for ManagedControlList instances
    """
    control = None
    pageSize = 8
    initialPageSize = 18  # + orphans = 26

    # the amount of overhang allowed for both sides; don't show pagination when the overhang fits the current item count
    orphans = pageSize
    offset = 0
    leafCount = None
    parentWindow = None
    thumbFallback = None

    _direction = None
    _currentAmount = None
    _lastAmount = None
    _boundaryHit = False

    def __init__(self, control, parent_window, page_size=None, orphans=None, leaf_count=None):
        self.control = control
        self.pageSize = page_size if page_size is not None else self.pageSize
        self.orphans = orphans if orphans is not None else self.pageSize
        self.leafCount = leaf_count
        self.parentWindow = parent_window

        self.reset()

    def reset(self):
        self.offset = 0
        self._currentAmount = 0
        self._lastAmount = None
        self._boundaryHit = False
        self._direction = None

    def getData(self, offset, amount):
        raise NotImplementedError

    def createListItem(self, data):
        return self.parentWindow.createListItem(data)

    def prepareListItem(self, data, mli):
        pass

    def readyForPaging(self):
        return self.parentWindow.initialized

    @property
    def _readyForPaging(self):
        return self.readyForPaging()

    @property
    def boundaryHit(self):
        self._boundaryHit = False

        if not self._readyForPaging:
            return

        mli = self.control.getSelectedItem()
        if mli and mli.getProperty("is.boundary") and not mli.getProperty("is.updating"):
            direction = "left" if mli.getProperty("left.boundary") else "right"
            mli.setBoolProperty("is.updating", True)
            self.offset = int(mli.getProperty("orig.index"))
            self._direction = direction
            self._boundaryHit = True

        return self._boundaryHit

    @property
    def nextPage(self):
        leafCount = self.leafCount
        offset = self.offset
        amount = self.pageSize

        if self._direction == "left":
            if offset <= self.initialPageSize:
                # return to initial page
                offset = 0
                amount = self.initialPageSize
            else:
                # move the slice to the left by :amount: based on :offset:
                amount = min(offset, self.pageSize)
                offset -= amount

            # avoid short pages on the left end
            if 0 < offset < self.orphans:
                amount += offset
                offset = 0

        else:
            # move the slice to the right
            itemsLeft = leafCount - offset
            # avoid short pages on the right end
            if itemsLeft <= self.pageSize + self.orphans:
                amount = self.pageSize + self.orphans

        self.offset = offset
        data = self.getData(offset, amount)
        self._lastAmount = self._currentAmount
        self._currentAmount = len(data)
        return data

    @property
    def initialPage(self):
        amount = self.initialPageSize
        if self.initialPageSize + self.orphans >= self.leafCount:
            amount = self.initialPageSize + self.orphans

        data = self.getData(self.offset, amount)
        if data:
            self._lastAmount = self._currentAmount
            self._currentAmount = len(data)
            return data

    def populate(self, items):
        """
        Populates the current page to the bound Control List. Adds prev/next MLIs and selects the correct control
        after doing so.
        :param items:
        :return:
        """
        idx = 0
        moreLeft = self.offset > 0
        moreRight = self.offset + self._currentAmount < self.leafCount

        finalItems = []
        thumbFallback = self.thumbFallback

        if items:
            for item in items:
                mli = self.createListItem(item)

                if mli:
                    mli.setProperty('index', str(idx))
                    self.prepareListItem(item, mli)
                    if thumbFallback:
                        if callable(thumbFallback):
                            mli.setProperty('thumb.fallback', thumbFallback(item))
                        else:
                            mli.setProperty('thumb.fallback', thumbFallback)

                    finalItems.append(mli)
                    idx += 1

            if moreRight:
                end = kodigui.ManagedListItem('')
                end.setBoolProperty('is.boundary', True)
                end.setBoolProperty('right.boundary', True)
                end.setProperty("orig.index", str(int(self.offset + self._currentAmount)))
                finalItems.append(end)
            else:
                # no boundary, rightmost item
                finalItems[-1].setBoolProperty('last.item', True)

            if moreLeft:
                start = kodigui.ManagedListItem('')
                start.setBoolProperty('is.boundary', True)
                start.setBoolProperty('left.boundary', True)
                start.setProperty("orig.index", str(int(self.offset)))
                finalItems.insert(0, start)

            self.control.replaceItems(finalItems)
            self.selectItem(self._currentAmount, more_left=moreLeft, more_right=moreRight, items=items)

        return finalItems

    def selectItem(self, amount, more_left=False, more_right=False, items=None):
        if self._direction:
            if self._direction == "left":
                self.control.selectItem(amount - (1 if not more_left else 0))
                return True

            elif self._direction == "right":
                self.control.selectItem(1)
                return True

    def paginate(self, force_page=False):
        """
        Triggers the pagination for the currently selected view. In case of a hit boundary, show the next or previous
        page, otherwise show the initial page.
        :return:
        """
        if self._boundaryHit or force_page:
            items = self.nextPage

        else:
            items = self.initialPage

        return self.populate(items)

    @property
    def canSimpleWrap(self):
        return self.initialPageSize + self.orphans >= self.leafCount

    def wrap(self, mli, last_mli, action):
        """
        Wraps around the list if the first or last item is currently selected and the user requests to round robin.
        :param mli: current item
        :param last_mli: previous item
        :param action: xbmcgui action
        :return:
        """

        index = int(mli.getProperty("index"))
        last_mli_index = int(last_mli.getProperty("index"))

        # special case for our absolute last item
        is_rightmost = action == xbmcgui.ACTION_MOVE_RIGHT \
            and mli.getProperty('last.item') \
            and last_mli.getProperty('last.item')

        # _lastAmount is used to immediately wrap again after a wrap has happened; potentially an issue
        if not is_rightmost and last_mli_index not in \
                (0, self._currentAmount - 1, (self._lastAmount - 1) if self._lastAmount else None) \
                or self._currentAmount < 2:
            return

        onlyTwo = self._currentAmount == 2

        items = None
        if action == xbmcgui.ACTION_MOVE_LEFT and index == 0 and last_mli_index == 0:
            if onlyTwo and last_mli_index == self._currentAmount - 1:
                return

            if not self.canSimpleWrap:
                self._direction = "right"
                self.offset = self.leafCount - self.orphans - self.pageSize
                items = self.paginate(force_page=True)
                self.control.selectItem(self._currentAmount)
            else:
                self.control.selectItem(self.leafCount - 1)
        elif action == xbmcgui.ACTION_MOVE_RIGHT and (index == self._currentAmount - 1 or is_rightmost):
            if onlyTwo and last_mli_index == 0:
                return

            if not self.canSimpleWrap:
                self._direction = "left"
                self.offset = 0
                items = self.paginate()
            self.control.selectItem(0)

        if items:
            return items


class BaseRelatedPaginator(MCLPaginator):
    """
    Unlike the base class's sliding-window paging (each page replaces the control's entire contents,
    keeping only a bounded number of items visible at once - appropriate for something like Episodes'
    own potentially very long episode list), related-item lists are short enough that once a page is
    loaded it should just stay - matching how recommended-hub rows behave (they only ever grow via
    hub.more(), never discard earlier items or re-fetch them). This fixes a real bug the base class's
    approach had here: paging right lost the earlier items (only a left-boundary marker remained to
    re-fetch them), and paging back left re-fetched - and briefly re-showed a loading placeholder for -
    items that had already been loaded once. So: append-only, right-direction-only pagination - no
    left-boundary marker is ever created, so boundaryHit's "left" branch is simply never reached here.
    """
    initialPageSize = 8
    pageSize = initialPageSize
    orphans = initialPageSize // 2

    # Music types map to music.png, not the 'movie' catch-all: ArtistWindow's Similar Artists row
    # (subitems.py) is the one related row that carries non-video items, and an artless artist tile
    # was showing a movie fallback next to album tiles whose own fallback fill() sets to music.png.
    # Inert for every other caller (preplay/subitems ShowWindow related rows never see these types).
    THUMB_FALLBACKS = {
        'show': 'show', 'season': 'show', 'episode': 'show',
        'artist': 'music', 'album': 'music', 'track': 'music',
    }

    thumbFallback = lambda self, rel: 'script.plex/thumb_fallbacks/{0}.png'.format(
        self.THUMB_FALLBACKS.get(rel.type, 'movie'))

    @property
    def nextPage(self):
        # Always continues from the total already shown so far - never re-slices backward, unlike the
        # base class's own nextPage.
        offset = self._currentAmount
        amount = self.pageSize
        itemsLeft = self.leafCount - offset
        if itemsLeft <= self.pageSize + self.orphans:
            amount = itemsLeft

        self.offset = offset
        data = self.getData(offset, amount)
        self._lastAmount = self._currentAmount
        self._currentAmount += len(data)
        return data

    def populate(self, items):
        if not items:
            return []

        priorAmount = self._lastAmount or 0
        moreRight = self._currentAmount < self.leafCount

        finalItems = []
        thumbFallback = self.thumbFallback
        idx = priorAmount
        for item in items:
            mli = self.createListItem(item)
            if not mli:
                continue

            mli.setProperty('index', str(idx))
            self.prepareListItem(item, mli)
            if thumbFallback:
                if callable(thumbFallback):
                    mli.setProperty('thumb.fallback', thumbFallback(item))
                else:
                    mli.setProperty('thumb.fallback', thumbFallback)

            finalItems.append(mli)
            idx += 1

        if not moreRight:
            finalItems[-1].setBoolProperty('last.item', True)

        appending = self._direction is not None
        if appending:
            # Drop the old trailing boundary marker (the item that triggered this page) before
            # appending the new items in its place, so it's the marker that's replaced, not any real
            # item - nothing already shown is ever removed.
            self.control.removeItem(self.control.size() - 1)
            selectPos = self.control.size()
        else:
            self.control.reset()
            selectPos = 0

        self.control.addItems(finalItems)

        if moreRight:
            end = kodigui.ManagedListItem('')
            end.setBoolProperty('is.boundary', True)
            end.setBoolProperty('right.boundary', True)
            end.setProperty("orig.index", str(self._currentAmount))
            self.control.addItems([end])

        if appending:
            self.control.setSelectedItemByPos(selectPos)

        return finalItems

    def createListItem(self, rel):
        return kodigui.ManagedListItem(
            rel.title or '',
            thumbnailImage=rel.defaultThumb.asTranscodedImageURL(*self.parentWindow.RELATED_DIM),
            data_source=rel
        )

    def prepareListItem(self, data, mli):
        if data.type in ('season', 'show'):
            if not mli.dataSource.isPlayed:
                mli.setProperty('unwatched.count', str(mli.dataSource.unViewedLeafCount) or '')
                mli.setBoolProperty('unwatched.count.large', mli.dataSource.unViewedLeafCount > 999)
            else:
                mli.setBoolProperty('watched', mli.dataSource.isPlayed)
        else:
            mli.setProperty('unwatched', not mli.dataSource.isWatched and '1' or '')
            mli.setBoolProperty('watched', mli.dataSource.isPlayed)
            mli.setProperty('progress', util.getProgressImage(mli.dataSource))


def isMoreSelected(control):
    """Whether a row's selected item is its "See more" tile (RowMaxMixin)."""
    mli = control.getSelectedItem()
    return bool(mli and mli.getProperty('is.more'))


class RowMaxMixin(object):
    """A BaseRelatedPaginator row as the hub rows are: its first ROW_MAX items in one request, then
    a "See more" tile (is.more, includes/hub_see_more_pill.xml.tpl) when its list holds more - no
    paging. Goes first in the bases, ahead of the paginator whose getData()/createListItem() it
    uses. total: how many the list holds - leafCount once getData() has run (the caller's count,
    or the listing's totalSize), at least what came back."""
    ROW_MAX = ROW_MAX
    total = 0

    @property
    def initialPage(self):
        data = self.getData(0, self.ROW_MAX) or []
        self.total = max(int(self.leafCount or 0), len(data))
        self._lastAmount = self._currentAmount
        self._currentAmount = len(data)
        return data

    def populate(self, items):
        finalItems = []
        thumbFallback = self.thumbFallback
        for item in (items or [])[:self.ROW_MAX]:
            mli = self.createListItem(item)
            if not mli:
                continue
            mli.setProperty('index', str(len(finalItems)))
            self.prepareListItem(item, mli)
            if thumbFallback:
                mli.setProperty('thumb.fallback', thumbFallback(item) if callable(thumbFallback) else thumbFallback)
            finalItems.append(mli)

        if not finalItems:
            self.control.reset()
            return finalItems

        rowItems = list(finalItems)
        if self.total > len(finalItems):
            more = kodigui.ManagedListItem(T(35093, 'See more'))
            more.setBoolProperty('is.more', True)
            rowItems.append(more)
        else:
            finalItems[-1].setBoolProperty('last.item', True)
        self.control.replaceItems(rowItems)
        return finalItems
