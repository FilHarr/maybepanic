from __future__ import absolute_import
import re
import six.moves.urllib.request, six.moves.urllib.parse, six.moves.urllib.error
import time

from . import plexapp
from . import plexrequest
from . import callback
from . import plexobjects
from . import util
from . import signalsmixin
from six.moves import range


class AudioUsage(object):
    def __init__(self, skipsPerHour, playQueueId):
        self.HOUR = 3600
        self.skipsPerHour = skipsPerHour
        self.playQueueId = playQueueId
        self.skips = []

    def allowSkip(self):
        if self.skipsPerHour < 0:
            return True
        self.updateSkips()
        return len(self.skips) < self.skipsPerHour

    def updateSkips(self, reset=False):
        if reset or len(self.skips) == 0:
            if reset:
                self.skips = []
            return

        # Remove old skips if applicable
        epoch = util.now()
        if self.skips[0] + self.HOUR < epoch:
            newSkips = []
            for skip in self.skips:
                if skip + self.HOUR > epoch:
                    newSkips.append(skip)
            self.skips = newSkips
            self.log("updated skips")

    def registerSkip(self):
        self.skips.append(util.now())
        self.updateSkips()
        self.log("registered skip")

    def allowSkipMessage(self):
        if self.skipsPerHour < 0 or self.allowSkip():
            return None
        return "You can skip {0} songs an hour per mix.".format(self.skipsPerHour)

    def log(self, prefix):
        util.DEBUG_LOG("AudioUsage {0}: total skips={1}, allowed skips={2}", prefix, lambda: len(self.skips),
                       self.skipsPerHour)


class UsageFactory(object):
    def __init__(self, play_queue):
        self.playQueue = play_queue
        self.type = play_queue.type
        self.usage = play_queue.usage

    @classmethod
    def createUsage(cls, playQueue):
        obj = cls(playQueue)

        if obj.type:
            if obj.type == "audio":
                return obj.createAudioUsage()
            elif obj.type == "photo":
                return obj.createPhotoUsage()

        util.DEBUG_LOG("Don't know how to usage for " + str(obj.type))
        return None

    def createPhotoUsage(self):
        if not self.usage or self.usage.playQueueId != self.playQueue.id:
            self.usage = self.playQueue.usage

        return self.usage

    def createAudioUsage(self):
        skips = self.playQueue.container.stationSkipsPerHour.asInt(-1)
        if skips == -1:
            return None

        # Create new usage if invalid, or if we start a new PQ, otherwise
        # we'll return the existing usage for the PQ.
        if not self.usage or self.usage.playQueueId != self.playQueue.id:
            self.usage = AudioUsage(skips, self.playQueue.id)

        return self.usage


class PlayOptions(util.AttributeDict):
    def __init__(self, *args, **kwargs):
        util.AttributeDict.__init__(self, *args, **kwargs)
        # At the moment, this is really just a glorified struct. But the
        # expected fields include key, shuffle, extraPrefixCount,
        # and unwatched. We may give this more definition over time.

        # These aren't widely used yet, but half inspired by a PMS discussion...
        self.CONTEXT_AUTO = 0
        self.CONTEXT_SELF = 1
        self.CONTEXT_PARENT = 2
        self.CONTEXT_CONTAINER = 3

        self.context = self.CONTEXT_AUTO


def createLocalPlayQueue(item, children, contentType, options):
    pass


class PlayQueueFactory(object):
    def getContentType(self, item):
        if item.isMusicOrDirectoryItem():
            return "audio"
        elif item.isVideoOrDirectoryItem():
            return "video"
        elif item.isPhotoOrDirectoryItem():
            return "photo"

        return None

    def canCreateRemotePlayQueue(self):
        if self.item.getServer().isSecondary():
            reason = "Server is secondary"
        elif not (self.item.isLibraryItem() or self.item.isGracenoteCollection() or self.item.isLibraryPQ or self.item.isCollection):
            reason = "Item is not a library item or gracenote collection"
        else:
            return True

        util.DEBUG_LOG("Requires local play queue: " + reason)
        return False

    def itemRequiresRemotePlayQueue(self):
        # TODO(rob): handle entire section? (if we create PQ's of sections)
        # return item instanceof PlexSection || item.type == PlexObject.Type.artist;
        return self.item.type == "artist"


def queueSourcePath(path):
    """A directory path as createRemotePlayQueue() sends it in a queue's uri - with a few params
    renamed to the PQ spec - and so as PMS hands it back in the queue's playQueueSourceURI
    (PlayQueue.sourcePath; the two match exactly, checked live 2026-10-07)."""
    if "/search" in path:
        return path

    # Convert a few params to the PQ spec
    convert = {
        'type': "sourceType",
        'unwatchedLeaves': "unwatched"
    }

    for key in convert:
        regex = re.compile(r"(?i)([?&])" + key + "=")
        # r"\1", not "\1": the latter is chr(1), so this used to swallow the ? or & it
        # matched and splice a control character into the path instead of keeping the
        # separator. It never fired before - the one caller that got here already passed
        # sourceType, and "sourceType=" doesn't match "([?&])type=" - but the artist's
        # <PopularLeaves> key ends in "&type=10", so now it does.
        path = regex.sub(r"\1" + convert[key] + "=", path)
    return path


def sameQueueSource(a, b):
    """Whether two queue source paths name the same container: equal, once a trailing /children
    is dropped from each - /library/metadata/<album>/children lists the album's tracks, so a
    queue of it is the album's, the same as one of /library/metadata/<album> (what both a track
    click and the album's Play button queue - PlayQueue.sourcePath)."""
    if not a or not b:
        return False

    def strip(p):
        return p[:-len('/children')] if p.endswith('/children') else p
    return strip(a) == strip(b)


def createPlayQueueForItem(item, children=None, options=None, args=None, use_async=True, method="GET", **kwargs):
    obj = PlayQueueFactory()

    contentType = obj.getContentType(item)
    if not contentType:
        # TODO(schuyler): We may need to try harder, but I'm not sure yet. For
        # example, what if we're shuffling an entire library?
        #
        # No reason to crash here. We can safely return None and move on.
        # We'll stop if we're in dev mode to catch and debug.
        #
        util.DEBUG_LOG("Don't know how to create play queue for item " + repr(item))
        return None

    obj.item = item

    options = PlayOptions(options or {})

    if obj.canCreateRemotePlayQueue():
        return createRemotePlayQueue(item, contentType, options, args, use_async=use_async, method=method, **kwargs)
    else:
        if obj.itemRequiresRemotePlayQueue():
            util.DEBUG_LOG("Can't create remote PQs and item does not support local PQs")
            return None
        else:
            return createLocalPlayQueue(item, children, contentType, options)


class PlayQueue(signalsmixin.SignalsMixin):
    # A queue PMS is still filling is read again after this many ms, up to this many times -
    # see rereadShortWindow(). Sized to finish well inside util.TIMEOUT (5s), which is what
    # waitForInitialization() gives the whole thing.
    WINDOW_RETRY_DELAY = 300
    WINDOW_RETRY_LIMIT = 4

    TYPE = 'playqueue'

    isRemote = True

    def __init__(self, server, contentType, options=None):
        signalsmixin.SignalsMixin.__init__(self)
        self.id = None
        self.selectedId = None
        self.version = -1
        self.isShuffled = False
        self.isRepeat = False
        self.isRepeatOne = False
        self.isLocalPlayQueue = False
        self.isMixed = None
        self.totalSize = 0
        self.windowSize = 0
        self.forcedWindow = False
        # The window last asked for, so a short answer can be told apart from a queue that is
        # simply longer than we asked for - see rereadShortWindow().
        self.requestedWindow = 0
        # Consecutive short reads of a queue the window should have covered, the size the last
        # of them came back at, and the size we stopped asking at - see rereadShortWindow().
        self.windowRetries = 0
        self.lastShortWindow = 0
        self.settledShortAt = 0
        self.container = None

        # Forced limitations
        self.allowShuffle = False
        self.allowSeek = True
        self.allowRepeat = False
        self.allowSkipPrev = False
        self.allowSkipNext = False
        self.allowAddToQueue = False

        self.refreshOnTimeline = False

        self.server = server
        self.type = contentType
        self._items = []
        self.options = options or util.AttributeDict()

        self.usage = None

        self.refreshTimer = None

        self.canceled = False
        self.responded = False
        self.failed = False
        self.initialized = False

        self.composite = plexobjects.PlexValue('', parent=self)

        # Add a few default options for specific PQ types
        if self.type == "photo":
            self.setRepeat(True)
        # Deliberately no includeRelated for audio: with it, PMS appends tracks it considers
        # similar, so playback carries on past the end of the album (or list) you asked for. An
        # audio queue here ends with its last track. On request, 2026-09-19.

    def get(self, name):
        return getattr(self, name, plexobjects.PlexValue('', parent=self))

    @property
    def sourcePath(self):
        """The path this queue was built from, from PMS's own playQueueSourceURI (kept through
        refreshes - checked live): "/library/metadata/31785" for an album, whether as the directory
        a track click queues (library://<id>/directory/...) or the item the album's own Play and
        Shuffle buttons queue (library://<id>/item/..., either way - checked live 2026-10-07); the
        artist's popular-tracks listing for one of those. '' for a playlist's queue
        (library://<id>/playlist/...) or one that hasn't answered yet."""
        # `is None`, not truthiness: a container can define __len__ (PlexServerContainer).
        if self.container is None:
            return ''
        uri = self.container.get('playQueueSourceURI') or ''
        for kind in ('/directory/', '/item/'):
            if kind in uri:
                return six.moves.urllib.parse.unquote(uri.split(kind, 1)[1])
        return ''

    @property
    def defaultArt(self):
        return self.current().defaultArt

    def waitForInitialization(self):
        start = time.time()
        timeout = util.TIMEOUT
        util.DEBUG_LOG('Waiting for playQueue to initialize...')
        while not self.canceled and not self.initialized and not self.failed:
            if not self.responded and time.time() - start > timeout:
                util.DEBUG_LOG('PlayQueue timed out wating for initialization')
                return self.initialized
            time.sleep(0.1)

        if self.initialized:
            util.DEBUG_LOG('PlayQueue initialized in {0:.2f} secs: {1}', time.time() - start, self)
        else:
            util.DEBUG_LOG('PlayQueue failed to initialize')

        return self.initialized

    def onRefreshTimer(self):
        self.refreshTimer = None
        self.refresh(True, False)

    def cancelRefresh(self):
        """Drops a delayed refresh still pending (refresh(delay=True)'s 5 s timer): for a queue
        being replaced by another, which PMS deletes as soon as the new one is made (one queue per
        client), so the refresh only ever came back 404 (PlexPlayer._retireAudioQueue())."""
        timer, self.refreshTimer = self.refreshTimer, None
        if timer:
            timer.cancel()

    def refresh(self, force=True, delay=False, wait=False):
        # Ignore refreshing local PQs
        if self.isLocal():
            return

        if wait:
            self.responded = False
            self.failed = False
            self.initialized = False
        # We refresh our play queue if the caller insists or if we only have a
        # portion of our play queue loaded. In particular, this means that we don't
        # refresh the play queue if we're asked to refresh because a new track is
        # being played but we have the entire album loaded already.

        if force or self.isWindowed():
            if delay:
                # We occasionally want to refresh the PQ in response to moving to a
                # new item and starting playback, but if we refresh immediately:
                # we probably end up refreshing before PMS realizes we've moved on.
                # There's no great solution, but delaying our refresh by just a few
                # seconds makes us much more likely to get an accurate window (and
                # accurate selected IDs) from PMS.

                if not self.refreshTimer:
                    self.refreshTimer = plexapp.createTimer(5000, self.onRefreshTimer)
                    util.APP.addTimer(self.refreshTimer)
            else:
                request = plexrequest.PlexRequest(self.server, "/playQueues/" + str(self.id))
                self.addRequestOptions(request)
                context = request.createRequestContext("refresh", callback.Callable(self.onResponse))
                util.APP.startRequest(request, context)

        if wait:
            return self.waitForInitialization()

    def shuffle(self, shuffle=True):
        self.setShuffle(shuffle)

    def setShuffle(self, shuffle=None):
        if shuffle is None:
            shuffle = not self.isShuffled

        if self.isShuffled == shuffle:
            return

        if shuffle:
            command = "/shuffle"
        else:
            command = "/unshuffle"

        # Don't change self.isShuffled, it'll be set in OnResponse if all goes well

        request = plexrequest.PlexRequest(self.server, "/playQueues/" + str(self.id) + command, "PUT")
        self.addRequestOptions(request)
        context = request.createRequestContext("shuffle", callback.Callable(self.onResponse))
        util.APP.startRequest(request, context)

    def setRepeat(self, repeat, one=False):
        if self.isRepeat == repeat and self.isRepeatOne == one:
            return

        self.options.repeat = repeat
        self.isRepeat = repeat
        self.isRepeatOne = one

    def moveItemUp(self, item):
        for index in range(1, len(self._items)):
            if self._items[index].get("playQueueItemID") == item.get("playQueueItemID"):
                if index > 1:
                    after = self._items[index - 2]
                else:
                    after = None

                self.swapItem(index, -1)
                self.moveItem(item, after)
                return True

        return False

    def moveItemDown(self, item):
        for index in range(len(self._items) - 1):
            if self._items[index].get("playQueueItemID") == item.get("playQueueItemID"):
                after = self._items[index + 1]
                self.swapItem(index)
                self.moveItem(item, after)
                return True

        return False

    def moveItem(self, item, after):
        if after:
            query = "?after=" + after.get("playQueueItemID", "-1")
        else:
            query = ""

        request = plexrequest.PlexRequest(self.server, "/playQueues/" + str(self.id) + "/items/" + item.get("playQueueItemID", "-1") + "/move" + query, "PUT")
        self.addRequestOptions(request)
        context = request.createRequestContext("move", callback.Callable(self.onResponse))
        util.APP.startRequest(request, context)

    def swapItem(self, index, delta=1):
        before = self._items[index]
        after = self._items[index + delta]

        self._items[index] = after
        self._items[index + delta] = before

    def removeItem(self, item):
        request = plexrequest.PlexRequest(self.server, "/playQueues/" + str(self.id) + "/items/" + item.get("playQueueItemID", "-1"), "DELETE")
        self.addRequestOptions(request)
        context = request.createRequestContext("delete", callback.Callable(self.onResponse))
        util.APP.startRequest(request, context)

    def addItem(self, item, addNext=False, excludeSeedItem=False):
        request = plexrequest.PlexRequest(self.server, "/playQueues/" + str(self.id), "PUT")
        request.addParam("uri", item.getItemUri())
        request.addParam("next", addNext and "1" or "0")
        request.addParam("excludeSeedItem", excludeSeedItem and "1" or "0")
        self.addRequestOptions(request)
        context = request.createRequestContext("add", callback.Callable(self.onResponse))
        util.APP.startRequest(request, context)

    def onResponse(self, request, response, context):
        # Close any loading modal regardless of response status
        # Application().closeLoadingModal()
        util.DEBUG_LOG('playQueue: Received response')
        self.responded = True
        if response.parseResponse():
            util.DEBUG_LOG('playQueue: {0} items', lambda: len(response.items))
            self.container = response.container
            # Handle an empty PQ if we have specified an pqEmptyCallable
            if self.options and self.options.pqEmptyCallable:
                callable = self.options.pqEmptyCallable
                del self.options["pqEmptyCallable"]
                if len(response.items) == 0:
                    callable.call()
                    return

            self.id = response.container.playQueueID.asInt()
            self.isShuffled = response.container.playQueueShuffled.asBool()
            self.totalSize = response.container.playQueueTotalCount.asInt()
            self.windowSize = len(response.items)
            self.version = response.container.playQueueVersion.asInt()

            # Placed before anything reads or writes self._items, so a window we are about to
            # throw away leaves no trace. Letting it land first made the next read look like an
            # addition rather than a replacement: the short window is a subset of the full one,
            # so the justAdded calculation below handed items.changed everything the short
            # window lacked, and AudioPlayerHandler.playQueueCallback appends what it is given
            # instead of rebuilding - shuffling tacked a second copy of the queue onto the end of
            # the first (live, 2026-09-19).
            #
            # Nothing is announced either: no initialized, change or items.changed. The caller
            # may still be inside waitForInitialization(), and letting a short queue through
            # would have playAudioPlaylist() build Kodi's playlist from it, leaving the next read
            # to patch it in place - the swap-and-remove dance that has caused trouble before.
            # Waiting means it is built once, complete.
            if self.rereadShortWindow(context):
                return

            itemsChanged = False
            justAdded = False

            if len(response.items) == len(self._items):
                for i in range(len(self._items)):
                    if self._items[i] != response.items[i]:
                        itemsChanged = True
                        break
            else:
                itemsChanged = True

                # What grew onto the end, in queue order - a list, never a set. The listener for
                # this is AudioPlayerHandler.playQueueCallback, which appends the items one by
                # one in the order it is handed them, and a set has no order to hand over: a
                # 234-track artist queue that arrived as 200 and then filled out appended its
                # last 34 tracks in hash order, so the queue read correctly by album to track 200
                # and was scrambled from there to the end.
                #
                # The test is also stricter than the old issubset(): those items have to be the
                # *head* of what came back, not merely present somewhere in it. Appending is only
                # the right move when the rest genuinely follows what we already hold - a window
                # that slid, or a shuffle, satisfies "is a subset" while needing every row
                # rebuilt, and that is what the empty justAdded below asks for.
                head = response.items[:len(self._items)]
                if head == self._items:
                    justAdded = response.items[len(self._items):]

            if itemsChanged:
                self._items = response.items

            # Process any forced limitations
            self.allowSeek = response.container.allowSeek.asBool()
            self.allowShuffle = (
                self.totalSize > 1 and response.container.allowShuffle.asBool() and not response.container.playQueueLastAddedItemID
            )
            self.allowRepeat = response.container.allowRepeat.asBool()
            self.allowSkipPrev = self.totalSize > 1 and response.container.allowSkipPrevious != "0"
            self.allowSkipNext = self.totalSize > 1 and response.container.allowSkipNext != "0"

            # Figure out the selected track index and offset. PMS tries to make some
            # of this easy, but it might not realize that we've advanced to a new
            # track, so we can't blindly trust it. On the other hand, it's possible
            # that PMS completely changed the PQ item IDs (e.g. upon shuffling), so
            # we might need to use its values. We iterate through the items and try
            # to find the item that we believe is selected, only settling for what
            # PMS says if we fail.

            playQueueOffset = None
            selectedId = None
            pmsSelectedId = response.container.playQueueSelectedItemID.asInt()
            self.deriveIsMixed()

            # lastItem = None  # Not used
            for index in range(len(self._items)):
                item = self._items[index]

                if not playQueueOffset and item.playQueueItemID.asInt() == pmsSelectedId:
                    playQueueOffset = response.container.playQueueSelectedItemOffset.asInt() - index + 1

                    # Update the index of everything we've already past, and handle
                    # wrapping indexes (repeat).
                    for i in range(index):
                        pqIndex = playQueueOffset + i
                        if pqIndex < 1:
                            pqIndex = pqIndex + self.totalSize

                        self._items[i].playQueueIndex = plexobjects.PlexValue(str(pqIndex), parent=self._items[i])

                if playQueueOffset:
                    pqIndex = playQueueOffset + index
                    if pqIndex > self.totalSize:
                        pqIndex = pqIndex - self.totalSize

                    item.playQueueIndex = plexobjects.PlexValue(str(pqIndex), parent=item)

                # If we found the item that we believe is selected: we should
                # continue to treat it as selected.
                # TODO(schuyler): Should we be checking the metadata ID (rating key)
                # instead? I don't think it matters in practice, but it may be
                # more correct.

                if not selectedId and item.playQueueItemID.asInt() == self.selectedId:
                    selectedId = self.selectedId

            if not selectedId:
                self.selectedId = pmsSelectedId

            # TODO(schuyler): Set repeat as soon as PMS starts returning it

            # Fix up the container for all our items
            response.container.address = "/playQueues/" + str(self.id)

            # Create usage limitations
            self.usage = UsageFactory.createUsage(self)

            self.initialized = True
            self.trigger("change")

            if itemsChanged:
                self.trigger("items.changed", just_added=justAdded)
        else:
            # An error status, or no answer at all, is still a response: without this,
            # waitForInitialization() would see responded set and spin until canceled.
            util.WARN_LOG('playQueue: {0} request failed (status {1})',
                          getattr(context, 'requestType', None), response.getStatus())
            self.failed = True

    def windowHolds(self):
        """How many items the window we last asked for can return: 2N+1, measured exactly."""
        return self.requestedWindow and (2 * self.requestedWindow + 1) or 0

    def rereadShortWindow(self, context):
        """Read the queue again when PMS hands back less of it than the window allows for.

        Returns True when another read is on its way, and the caller then drops this response
        without announcing it.

        There are two separate reasons a response comes up short, and they need different
        answers. Both were measured against PMS 1.43.4 on 2026-09-19, by creating one queue over
        a 234-track artist and watching it.

        1. PMS ignores window= on anything that creates or changes a queue - create, own,
           shuffle, move, delete, add - and applies its own default of 10 instead, so the answer
           holds 21 items whatever we asked for. A plain read honours window= exactly. So any
           response but a "refresh" is read back straight away.

        2. A queue is not fully populated when PMS answers the create. The read at t+0.28s
           returned 200 of 234, and the read at t+0.50s returned all 234 and stayed there: the
           200 is a fill batch, not a ceiling. So a *read* that is still short gets asked again
           shortly, a few times, as long as the window could have covered the whole queue.

        That last condition is what keeps this finite. A queue genuinely longer than 2N+1 is
        short on every read no matter how often we ask, so it settles for what it can have.

        Two more stops for a queue PMS never completes. Two reads in a row at the same size
        means the server has finished filling, whatever playQueueTotalCount says - seen live
        after an unshuffle, where PMS reported 234, returned 233, and had a hole in its own
        playQueueItemID sequence: the four re-reads all came back 233 and only the limit ended
        it. The retry limit stays as the backstop behind that. Either way the queue publishes
        what it has, and says so once rather than on every refresh for as long as it lives.
        """
        if self.type != "audio" or self.totalSize <= self.windowSize:
            self.windowRetries = self.lastShortWindow = self.settledShortAt = 0
            return False

        if context.requestType != "refresh":
            # A fresh cycle: whatever an earlier one settled on no longer applies, since the
            # queue has just been changed under it. Without this the counter stayed at the
            # limit after one exhausted cycle and every later shuffle got no re-reads at all.
            self.windowRetries = self.lastShortWindow = self.settledShortAt = 0
            delay = 0
        elif self.totalSize > self.windowHolds():
            # Longer than the window can return - this really is all of it we can have.
            return False
        elif self.settledShortAt == self.windowSize:
            # Already gave up at this size and said so; the periodic refresh keeps asking for
            # as long as a windowed queue plays, and does not need a log line every time.
            return False
        elif self.windowSize == self.lastShortWindow or self.windowRetries >= self.WINDOW_RETRY_LIMIT:
            util.DEBUG_LOG('playQueue: settled at {0} of {1} items after {2} re-read(s) - going '
                           'with it', self.windowSize, self.totalSize, self.windowRetries)
            self.settledShortAt = self.windowSize
            return False
        elif self.refreshTimer:
            # Something else is already going to refresh us; stacking a second timer on top of
            # it would leave whichever loses the race holding a stale response.
            return False
        else:
            delay = self.WINDOW_RETRY_DELAY

        util.DEBUG_LOG('playQueue: {0} returned {1} of {2} items - reading it again{3}',
                       context.requestType, self.windowSize, self.totalSize,
                       delay and ' in {0}ms'.format(delay) or '')

        # responded back to False so waitForInitialization() keeps its timeout: that loop only
        # honours the timeout while responded is False, and spins indefinitely once it is True,
        # so leaving it set would hang the caller if the read never lands. Every wait here has to
        # finish well inside util.TIMEOUT (5s), which WINDOW_RETRY_LIMIT x WINDOW_RETRY_DELAY is
        # sized for.
        self.responded = False

        if delay:
            self.windowRetries += 1
            self.lastShortWindow = self.windowSize
            self.refreshTimer = plexapp.createTimer(delay, self.onRefreshTimer)
            util.APP.addTimer(self.refreshTimer)
        else:
            self.refresh(force=True)
        return True

    def isWindowed(self):
        return (not self.isLocal() and (self.totalSize > self.windowSize or self.forcedWindow))

    def hasNext(self):
        if self.isRepeatOne:
            return True

        items = list(self.items())
        current = self.current()
        # current() is None between a track starting and the queue catching up with it, and an
        # empty or failed-to-window queue has nothing to skip to either way.
        if current is None or current not in items:
            return False

        if items.index(current) < len(items) - 1:
            return True

        # Sitting on the last item we hold. Only two things can follow it: more of the queue that
        # PMS hasn't sent yet, or a wrap back to the top when repeat-all is on.
        #
        # This used to key off allowSkipNext and fell through to `return True` on the last item
        # whatever its value, so Next stayed live at the end of a queue and clicking it got Kodi's
        # "cannot find a next item to play" banner (live, 2026-09-19).
        return self.isWindowed() or self.isRepeat

    def hasPrev(self):
        items = list(self.items())
        current = self.current()
        if current is None or current not in items:
            return False

        if items.index(current) > 0:
            return True

        # Mirror of hasNext(): on the first item we hold, repeat-all wraps backwards to the last
        # one (CPlayListPlayer::PlayPrevious - "if (iSong < 0 && Repeated(...)) iSong =
        # playlist.size() - 1"), and a windowed queue has more sitting before it on the server.
        return self.isWindowed() or self.isRepeat

    def next(self):
        if self.isRepeatOne:
            return self.current()

        item = self.getNext()
        if not item:
            return None

        self.selectedId = item.playQueueItemID.asInt()
        self.trigger("current.changed")
        return item

    __next__ = next

    def prev(self):
        if self.isRepeatOne:
            return self.current()

        item = self.getPrev()
        if not item:
            return None

        self.selectedId = item.playQueueItemID.asInt()
        self.trigger("current.changed")
        return item

    def getPrev(self):
        if not self.hasPrev():
            return None

        pos = list(self.items()).index(self.current()) - 1
        return list(self.items())[pos]

    def getNext(self):
        if not self.hasNext():
            return None

        pos = list(self.items()).index(self.current()) + 1
        if pos >= len(self.items()):
            if not self.isRepeat or self.isWindowed():
                return None
            pos = 0

        return list(self.items())[pos]


    def setCurrent(self, pos):
        if pos < 0 or pos >= len(list(self.items())):
            return False

        item = list(self.items())[pos]
        self.selectedId = item.playQueueItemID.asInt()
        self.trigger("current.changed")
        return item

    def setCurrentItem(self, item):
        self.selectedId = item.playQueueItemID.asInt()
        self.trigger("current.changed")

    def __eq__(self, other):
        if not other:
            return False
        if self.__class__ != other.__class__:
            return False
        return self.id == other.id and self.type == other.type

    def __ne__(self, other):
        return not self.__eq__(other)

    def addRequestOptions(self, request):
        boolOpts = ["repeat", "includeRelated"]
        for opt in boolOpts:
            if self.options.get(opt):
                request.addParam(opt, "1")

        if self.type == "audio":
            # How much of the queue PMS hands back. window=N means N either side of the selected
            # item, so 2N+1 items, clamped to the queue's length. Measured exactly, against a
            # 234-track queue on PMS 1.43.4 (2026-09-19): window=10 gave 11, window=100 gave 101,
            # window=1000 gave all 234, and no window at all gave 21 - so PMS's own default is 10.
            #
            # X-Plex-Container-Size does not get round this: asking for 1000 with no window still
            # returned 21, so container paging works inside the window rather than instead of it.
            # Anything that wants more of the queue has to raise the window, not page past it.
            #
            # Audio only, because audio is the one type with a queue the user sits and scrolls
            # (the play queue screen). Without this it showed 41 rows of a 100-track queue, and
            # the rest only arrived as playback approached them, dropping tracks off the top as it
            # went. playlist_max_size halved: that setting is already this addon's limit on how
            # many items it will put in Kodi's playlist, and the window is what goes there, so
            # 2N+1 lands on the setting rather than double it.
            window = int(util.INTERFACE.getPreference("playlist_max_size", 500)) // 2
            self.requestedWindow = window
            if window > 0:
                request.addParam("window", str(window))

        intOpts = ["extrasPrefixCount"]
        for opt in intOpts:
            if self.options.get(opt):
                request.addParam(opt, str(self.options.get(opt)))

        includeChapters = self.options.get('includeChapters') is not None and self.options.includeChapters or 1
        request.addParam("includeChapters", str(includeChapters))

    def __repr__(self):
        return (
            str(self.__class__.__name__) + " " +
            str(self.type) + " windowSize=" +
            str(self.windowSize) + " totalSize=" +
            str(self.totalSize) + " selectedId=" +
            str(self.selectedId) + " shuffled=" +
            str(self.isShuffled) + " repeat=" +
            str(self.isRepeat) + " mixed=" +
            str(self.isMixed) + " allowShuffle=" +
            str(self.allowShuffle) + " version=" +
            str(self.version) + " id=" + str(self.id)
        )

    def isLocal(self):
        return self.isLocalPlayQueue

    def deriveIsMixed(self):
        if self.isMixed is None:
            self.isMixed = False

        lastItem = None
        for item in self._items:
            if not self.isMixed:
                if not item.get("parentKey"):
                    self.isMixed = True
                else:
                    self.isMixed = lastItem and item.get("parentKey") != lastItem.get("parentKey")

                lastItem = item

    def items(self):
        return self._items

    def current(self):
        for item in self.items():
            if item.playQueueItemID.asInt() == self.selectedId:
                return item

        return None

    def prevItem(self):
        last = None
        for item in self.items():
            if item.playQueueItemID.asInt() == self.selectedId:
                return last
            last = item

        return None


def createRemotePlayQueue(item, contentType, options, args, use_async=True, method="GET", **kwargs):
    util.DEBUG_LOG('Creating remote playQueue request...')
    obj = PlayQueue(item.getServer(), contentType, options)

    # The item's URI is made up of the library section UUID, a descriptor of
    # the item type (item or directory), and the item's path, URL-encoded.

    uri = "library://" + item.getLibrarySectionUuid() + "/"
    itemType = item.isDirectory() and "directory" or "item"
    path = None

    if not options.key:
        # if item.onDeck and len(item.onDeck) > 0:
        #     options.key = item.onDeck[0].getAbsolutePath("key")
        # el
        if not item.isDirectory():
            options.key = item.get("key")

    # If we're asked to play unwatched, ignore the option unless we are unwatched.
    options.unwatched = options.unwatched and item.isUnwatched()

    # TODO(schuyler): Until we build postplay, we're not allowed to queue containers for episodes.
    if item.type == "episode":
        options.context = options.CONTEXT_SELF
    elif item.type == "movie":
        if not options.extrasPrefixCount and not options.resume:
            options.extrasPrefixCount = util.INTERFACE.getPreference("cinema_trailers", 0)

    # How exactly to construct the item URI depends on the metadata type, though
    # whenever possible we simply use /library/metadata/:id.

    if item.isLibraryItem() and not item.isLibraryPQ:
        path = "/library/metadata/" + item.ratingKey
    else:
        path = item.getAbsolutePath("key")

    if options.context == options.CONTEXT_SELF:
        # If the context is specifically for just this item,: just use the
        # item's key and get out.
        pass
    elif item.type == "playlist":
        path = None
        uri = item.get("ratingKey")
        options.isPlaylist = True
    elif item.type == "track":
        # The track's own album, unless the caller names a container. Clicking a track queues its
        # album wherever it was clicked from - the album screen, the library's Tracks list view, a
        # hub, search - so the album comes first and container.address is only a last resort.
        #
        # That order matters, it isn't just a preference: for a track drawn from a paginated
        # listing, container.address carries the X-Plex-Container-Start/Size that
        # LibrarySection.items() (plexlibrary.py) baked into the path, so it describes one page of
        # results rather than a queue. containerPath is for the callers that do have a real
        # listable directory to queue - ArtistWindow.popularTrackClicked() passes the artist's
        # <PopularLeaves> key (subitems.py).
        parentRatingKey = item.get("parentRatingKey", "")
        path = (options.containerPath or (parentRatingKey and "/library/metadata/" + parentRatingKey) or
                (item.container and item.container.address))
        itemType = "directory"
    elif item.isPhotoOrDirectoryItem():
        if item.type != "photoalbum" and not item.parentKey and not item.isDirectory() and not item.isFullObject():
            # Photos surfaced via a hub (e.g. Home's "recently added") are partial objects - the
            # lightweight hub listing omits parentKey/parentRatingKey entirely (confirmed live:
            # both empty, only librarySectionID present). A full /library/metadata/{id} fetch does
            # carry the album hierarchy, same as Movie.genres()'s reload-on-demand in video.py.
            # Without this, item.container.address (the hub's own endpoint, not a listable album
            # directory) was used instead, and the server silently returned an empty windowed
            # queue for it.
            item.reload(soft=True)

        if item.type == "photoalbum" or item.parentKey:
            path = item.getParentPath(item.type == "photoalbum" and "key" or "parentKey")
            itemType = "item"
        elif item.isDirectory():
            path = item.getAbsolutePath("key")
        elif item.get("parentRatingKey"):
            path = "/library/metadata/" + item.get("parentRatingKey")
            itemType = "item"
        elif item.getLibrarySectionId():
            # No album parent at all - confirmed live: even after the reload above, this item has
            # neither parentKey nor parentRatingKey, meaning it isn't organized into an album (a
            # flat photo library), not just missing from a lightweight hub listing. There's no
            # album directory to window a queue around, so fall back to the section's own "all"
            # listing - unlike item.container.address (whatever endpoint the item happened to be
            # fetched through, e.g. a hub aggregation that isn't a real listable directory), this
            # is guaranteed to be a genuine directory the photo is an actual child of.
            path = "/library/sections/{0}/all".format(item.getLibrarySectionId())
            itemType = "directory"
            options.key = item.getAbsolutePath("key")
        else:
            path = item.container.address
            itemType = "directory"
            options.key = item.getAbsolutePath("key")

    elif item.type == "episode":
        path = "/library/metadata/" + item.get("grandparentRatingKey", "")
        itemType = "directory"
        options.key = item.getAbsolutePath("key")
    # elif item.type == "show":
    #     path = "/library/metadata/" + item.get("ratingKey", "")

    if path:
        if args:
            path += util.joinArgs(args)

        util.DEBUG_LOG("playQueue path: " + str(path))

        path = queueSourcePath(path)

        util.DEBUG_LOG("playQueue path: " + str(path))
        uri = uri + itemType + "/" + six.moves.urllib.parse.quote_plus(path)

    util.DEBUG_LOG("playQueue uri: " + str(uri))

    # Create the PQ request
    request = plexrequest.PlexRequest(obj.server, "/playQueues")
    request.addParam(not options.isPlaylist and "uri" or "playlistID", uri)
    request.addParam("type", contentType)
    
    for k, v in kwargs.items():
        request.addParam(k, str(v))
    # request.addParam('X-Plex-Client-Identifier', util.INTERFACE.getGlobal('clientIdentifier'))

    # Add options we pass once during PQ creation
    if options.shuffle:
        request.addParam("shuffle", "1")
        options.key = None
    else:
        request.addParam("shuffle", "0")

    if options.key:
        request.addParam("key", options.key)

    # Add options we pass every time querying PQs
    obj.addRequestOptions(request)

    util.DEBUG_LOG('Initial playQueue request started...')
    if use_async:
        context = request.createRequestContext("create", callback.Callable(obj.onResponse))
        util.APP.startRequest(request, context, body='')
    else:
        #xml = request.getToStringWithTimeout(timeout=util.PLEXTV_TIMEOUT)
        return request.postWithTimeout()

    return obj


def createPlayQueueForId(id, server=None, contentType=None):
    obj = PlayQueue(server, contentType)
    obj.id = id

    request = plexrequest.PlexRequest(server, "/playQueues/" + str(id))
    request.addParam("own", "1")
    obj.addRequestOptions(request)
    context = request.createRequestContext("own", callback.Callable(obj.onResponse))
    util.APP.startRequest(request, context)

    return obj


class AudioPlayer():
    pass


class VideoPlayer():
    pass


class PhotoPlayer():
    pass


def addItemToPlayQueue(item, addNext=False):
    # See if we have an active play queue for this self.dia type or if we need to
    # create one.

    if item.isMusicOrDirectoryItem():
        player = AudioPlayer()
    elif item.isVideoOrDirectoryItem():
        player = VideoPlayer()
    elif item.isPhotoOrDirectoryItem():
        player = PhotoPlayer()
    else:
        player = None

    if not player:
        util.ERROR_LOG("Don't know how to add item to play queue: " + str(item))
        return None
    elif not player.allowAddToQueue():
        util.DEBUG_LOG("Not allowed to add to this player")
        return None

    if player.playQueue:
        playQueue = player.playQueue
        playQueue.addItem(item, addNext)
    else:
        options = PlayOptions()
        options.context = options.CONTEXT_SELF
        playQueue = createPlayQueueForItem(item, None, options)
        if playQueue:
            player.setPlayQueue(playQueue, False)

    return playQueue
