<!-- Square item layout (240x240) - uses hub_id variable.
     Card recipe matches the music screens' square grid (script-plex-squares.xml.tpl) and the
     Artist screen's album rows (includes/artist_album_row.xml.tpl) exactly: 240 art, thumb+24
     drop-shadow-directional.png plate inset (-3,-3) for a 3px top/left, 21px bottom/right spread.
     Grew from 220 on request (2026-09-20) so square hub tiles are the same size as everywhere else.
     Item width 272 = 240 art + 32 gap: the art sits 8px into the item (the outer group's own 5 +
     the card group's 3), so adjacent tiles' art is 32px apart - the same art-to-art gap the
     episode screen's 16:9 row uses (script-plex-episodes.xml.tpl's 544-wide items / 512 art). -->
<itemlayout width="272" condition="String.IsEqual(Window.Property(hub.display.{{ hub_id }}),square)">
    <control type="group">
        <!-- 5, not 55: compensates for the parent grouplist's posx moving from 55 to 105
             (see script-plex-recommended.xml.tpl) so this item's resting position is unchanged. -->
        <posx>5</posx>
        <!-- Always top-anchored - see hub_itemlayout_poster.xml.tpl's own matching comment for why
             peek-above's crop no longer needs a manual per-type posy override here. -->
        <!-- 52, matching hub_itemlayout_poster.xml.tpl (was 72): the same title-to-art gap on
             every row type, on request (2026-09-20). ROW_CONTENT_HEIGHT (library.py) dropped by
             the same 20 for this type. -->
        <posy>{{ vscale(52) }}</posy>
        <control type="group">
            <!-- The whole card is hidden for the row's "See more" item (is.more) - see
                 includes/hub_see_more_pill.xml.tpl, the sibling below that shows in its place. -->
            <visible>String.IsEmpty(ListItem.Property(is.more))</visible>
            <control type="image">
                <posx>0</posx>
                <posy>0</posy>
                <width>264</width>
                <height>{{ vscale(264) }}</height>
                <texture border="24">script.plex/drop-shadow-directional.png</texture>
            </control>
            <posx>3</posx>
            <posy>3</posy>
            <control type="image">
                <!-- Fill for is.photo's letterboxed thumb below - photos keep their full frame
                     (no crop) so this shows through wherever the image doesn't reach. -->
                <visible>!String.IsEmpty(ListItem.Property(is.photo))</visible>
                <posx>0</posx>
                <posy>0</posy>
                <width>240</width>
                <height>{{ vscale(240) }}</height>
                <texture diffuse="script.plex/masks/square-mask.png">script.plex/white-square.png</texture>
                <colordiffuse>FF191B1E</colordiffuse>
            </control>
            <!-- The placeholder card, under the art while it loads (see hub_itemlayout_poster.xml.tpl) -->
            <control type="image">
                <visible>String.IsEmpty(ListItem.Property(is.photo))</visible>
                <posx>0</posx>
                <posy>0</posy>
                <width>240</width>
                <height>{{ vscale(240) }}</height>
                <texture diffuse="script.plex/masks/square-mask.png">script.plex/white-square.png</texture>
                <aspectratio scalediffuse="false">scale</aspectratio>
                <colordiffuse>0AFFFFFF</colordiffuse>
            </control>
            <control type="image">
                <!-- fallback=: shown while ListItem.Thumb is empty (no URL yet) or failed - not while
                     it loads; the placeholder card above covers that (hub_itemlayout_poster.xml.tpl). -->
                <visible>String.IsEmpty(ListItem.Property(is.photo))</visible>
                <posx>0</posx>
                <posy>0</posy>
                <width>240</width>
                <height>{{ vscale(240) }}</height>
                <texture background="true" diffuse="script.plex/masks/square-mask.png" fallback="$INFO[ListItem.Property(thumb.fallback)]">$INFO[ListItem.Thumb]</texture>
                <aspectratio scalediffuse="false">scale</aspectratio>
            </control>
            <control type="image">
                <!-- Real photos vary wildly in aspect ratio - crop-to-fill (like posters/art) would
                     chop off arbitrary parts of someone's actual photo, so these get shown whole
                     and letterboxed instead, matching Plex's own photo hub presentation. -->
                <visible>!String.IsEmpty(ListItem.Property(is.photo))</visible>
                <posx>0</posx>
                <posy>0</posy>
                <width>240</width>
                <height>{{ vscale(240) }}</height>
                <texture background="true" diffuse="script.plex/masks/square-mask.png" fallback="$INFO[ListItem.Property(thumb.fallback)]">$INFO[ListItem.Thumb]</texture>
                <aspectratio scalediffuse="false">keep</aspectratio>
            </control>
            <control type="group">
                <!-- The poster tile's progress bar (hub_itemlayout_poster.xml.tpl), on request (2026-09-29):
                     inset 8px, 3px above the art's bottom edge, pill-masked, the same colours. -->
                <visible>!String.IsEmpty(ListItem.Property(progress))</visible>
                <posx>8</posx>
                <posy>{{ vscale(232) }}</posy>
                <control type="image">
                    <posx>0</posx>
                    <posy>0</posy>
                    <width>224</width>
                    <height>{{ vscale(5) }}</height>
                    <texture diffuse="script.plex/masks/progress-bar-mask-224.png">script.plex/white-square.png</texture>
                    <colordiffuse>E60A0F1A</colordiffuse>
                </control>
                <control type="image">
                    <posx>0</posx>
                    <posy>0</posy>
                    <width>224</width>
                    <height>{{ vscale(5) }}</height>
                    <texture diffuse="script.plex/masks/progress-bar-mask-224.png">$INFO[ListItem.Property(progress)]</texture>
                    <colordiffuse>FFE5A00D</colordiffuse>
                </control>
            </control>
            <!-- hub.nolabels.<id> (LibraryWindow.getHubRenderFlags()'s no_labels, library.py):
                 music hubs (album/artist/track items) show bare art with nothing underneath, on
                 request (2026-09-20); photo and playlist hubs keep their captions. Row height
                 follows this too - ROW_CONTENT_HEIGHT_SQUARE_NO_LABELS. -->
            <control type="label">
                <visible>String.IsEmpty(Window.Property(hub.nolabels.{{ hub_id }}))</visible>
                <scroll>false</scroll>
                <posx>0</posx>
                <posy>{{ vscale(250) }}</posy>
                <width>240</width>
                <height>{{ vscale(35) }}</height>
                <font>font10</font>
                <align>center</align>
                <textcolor>FFFFFFFF</textcolor>
                <label>$INFO[ListItem.Label]</label>
            </control>
            <control type="label">
                <visible>String.IsEmpty(Window.Property(hub.nolabels.{{ hub_id }})) + !String.IsEmpty(Window.Property(hub.text2lines.{{ hub_id }}))</visible>
                <scroll>false</scroll>
                <posx>0</posx>
                <posy>{{ vscale(277) }}</posy>
                <width>240</width>
                <height>{{ vscale(35) }}</height>
                <font>font10</font>
                <align>center</align>
                <!-- AAFFFFFF, not FFFFFFFF: the music grid's own second-line colour (script-plex-squares.xml.tpl's
                     album.artist label) - title bright, detail line dimmed. -->
                <textcolor>AAFFFFFF</textcolor>
                <label>$INFO[ListItem.Label2]</label>
            </control>
        </control>
        {% include "includes/hub_see_more_pill.xml.tpl" with px=3 & py=98 %}
    </control>
</itemlayout>
