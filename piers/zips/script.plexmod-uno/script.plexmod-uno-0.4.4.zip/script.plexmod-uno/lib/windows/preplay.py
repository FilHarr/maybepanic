from __future__ import absolute_import

import os

from kodi_six import xbmc
from kodi_six import xbmcgui
from plexnet import plexplayer, media, plexobjects, util as pnUtil, plexapp, plexlibrary, playlist, playqueue

from lib import metadata
from lib import util
from lib.util import T
from lib.language_util import getNativeLanguages
from . import busy
from . import grid_labels
from . import info
from . import kodigui
from . import opener
from . import optionsdialog
from . import pagination
from . import playersettings
from . import videoplayer
from . import windowutils
from .mixins.ratings import RatingsMixin
from .mixins.media_info_pills import MediaInfoPillsMixin
from .mixins.playbackbtn import PlaybackBtnMixin
from .mixins.thememusic import ThemeMusicMixin
from .mixins.watchlist import WatchlistUtilsMixin, autoRemoveFromWatchlistBlind
from .mixins.roles import RolesMixin
from .mixins.common import CommonMixin
from .mixins.tasks import TasksMixin
from .mixins.row_restore import RowRestoreMixin

VIDEO_RELOAD_KW = dict(includeExtras=1, includeExtrasCount=10, includeChapters=1, includeReviews=1)


class RelatedPaginator(pagination.BaseRelatedPaginator):
    def getData(self, offset, amount):
        return self.parentWindow.video.getRelated(offset=offset, limit=amount)

    def createListItem(self, rel):
        return kodigui.ManagedListItem(
            rel.title or '',
            grid_labels.editionLine(rel),
            thumbnailImage=rel.defaultThumb.asTranscodedImageURL(*self.parentWindow.RELATED_DIM),
            data_source=rel
        )


class CollectionPaginator(pagination.BaseRelatedPaginator):
    initialPageSize = 10
    pageSize = 8
    orphans = 4
    thumbFallback = 'script.plex/thumb_fallbacks/movie.png'

    def setup(self, server, path):
        self._server = server
        self._path = path
        return self

    @property
    def initialPage(self):
        data = self.getData(self.offset, self.initialPageSize)
        if data:
            self._lastAmount = self._currentAmount
            self._currentAmount = len(data)
            return data

    def getData(self, offset, amount):
        items = plexobjects.listItems(self._server, self._path, offset=offset, limit=amount)
        if not self.leafCount:
            self.leafCount = int(items.totalSize or 0) or len(items)
        return items

    def createListItem(self, item):
        return kodigui.ManagedListItem(
            item.title or '',
            grid_labels.editionLine(item),
            thumbnailImage=item.defaultThumb.asTranscodedImageURL(*self.parentWindow.RELATED_DIM),
            data_source=item
        )

    def prepareListItem(self, item, mli):
        mli.setProperty('unwatched', not item.isWatched and '1' or '')
        mli.setBoolProperty('watched', item.isPlayed)
        mli.setProperty('progress', util.getProgressImage(item))


# A server item's rows: the first 20 and "See more", as the hub rows (pagination.RowMaxMixin). A
# Watchlist item's keep paging (the user, 2026-10-09): its Related is Discover's.
class RelatedRowPaginator(pagination.RowMaxMixin, RelatedPaginator):
    pass


class CollectionRowPaginator(pagination.RowMaxMixin, CollectionPaginator):
    pass


class PrePlayWindow(kodigui.ControlledWindow, windowutils.UtilMixin, windowutils.SidebarMixin, RatingsMixin,
                    MediaInfoPillsMixin, PlaybackBtnMixin, ThemeMusicMixin, RolesMixin, CommonMixin,
                    WatchlistUtilsMixin, TasksMixin, RowRestoreMixin):
    xmlFile = 'script-plex-pre_play.xml'
    path = util.ADDON.getAddonInfo('path')
    theme = 'Main'
    res = '1080i'
    width = 1920
    height = 1080

    supportsAutoPlay = True
    # back-out of preplay can leave the window lingering on the stack until a parent
    # re-activate; actively dismiss it on NAV_BACK (see ControlledWindow.onAction)
    dismissOnClose = True

    RELATED_DIM = util.scaleResolution(268, 402)
    # 533x300 = 512x288 display size (script-plex-pre_play.xml.tpl's extras row) * 104%, the row's own
    # focus-zoom end value - same "fetch at the zoomed-in size, not the at-rest one" pattern the old
    # 299x168 art used (329x185 was that at 110%, its own zoom end value at the time). Shared with
    # ShowWindow's own EXTRA_DIM (subitems.py) - both rows use the same art recipe.
    EXTRA_DIM = util.scaleResolution(533, 300)
    ROLES_DIM = util.scaleResolution(334, 334)
    CLEAR_LOGO_DIM = util.scaleResolution(722, 162)

    ROLES_LIST_ID = 400
    REVIEWS_LIST_ID = 401
    EXTRA_LIST_ID = 402
    RELATED_LIST_ID = 403
    COLLECTION_LIST_IDS = [404, 405, 406]

    OPTIONS_GROUP_ID = 200

    MAIN_BUTTON_GROUP_ID = 300
    # The button rows' shared numbering (ShowWindow's constants, subitems.py), Trailer this screen's own 330
    PLAY_BUTTON_ID = 301
    OPTIONS_BUTTON_ID = 303
    INFO_BUTTON_ID = 304
    TRAILER_BUTTON_ID = 330
    # Play splits into these two once the video has a view offset (in.progress - setInfo() below),
    # matching Episodes' own button row.
    RESUME_BUTTON_ID = 305
    RESTART_BUTTON_ID = 307
    # Click/focus target laid over the summary textbox (script-plex-pre_play.xml.tpl) - 350, as on
    # every screen, not something in the 300-309 button cluster or 310-322
    # (includes/media_info_pills.xml.tpl's own ids, also live in this window - 310 specifically
    # collided with that include's video-pill background image, live-reported as "the background
    # does not extend the full length of the label": Control.setWidth() calls meant for that pill
    # (MediaInfoPillsMixin.resizeMediaInfoPills()) were hitting this button instead, since Kodi
    # doesn't guarantee which same-id control a getControl() call resolves to). Wired to
    # summaryButtonClicked() below.
    SUMMARY_BUTTON_ID = 350

    PLAYER_STATUS_BUTTON_ID = 204

    def __init__(self, *args, **kwargs):
        kodigui.ControlledWindow.__init__(self, *args, **kwargs)
        PlaybackBtnMixin.__init__(self)
        WatchlistUtilsMixin.__init__(self)
        TasksMixin.__init__(self)
        self.video = kwargs.get('video')
        self.parentList = kwargs.get('parent_list')
        self.fromWatchlist = kwargs.get('from_watchlist', False)
        self.isExternal = kwargs.get('external_item', False)
        self.directlyFromWatchlist = kwargs.get('directly_from_watchlist')
        self.is_watchlisted = kwargs.get('is_watchlisted', False)
        self.startOver = kwargs.get('start_over')

        # Sidebar entry-section persistence (ported from Sidebar-Tab-Unification's
        # mellow-pondering-magpie.md, 2026-08-18): which sidebar row should stay highlighted while
        # drilling through content, regardless of which section the item actually on screen
        # belongs to - set once here (not recomputed per buildSectionList() call) so every window
        # this one goes on to open can inherit it unchanged. None/False here means "nobody passed
        # one down" - this window is itself a genesis point (opened from the sidebar/Home/Search/
        # Watchlist), so it falls back to the same real-section-of-the-item computation
        # buildSectionList() always used before this.
        self.entrySectionId = kwargs.get('entry_section_id')
        self.entryFromWatchlist = kwargs.get('entry_from_watchlist', False)
        if self.entrySectionId is None and not self.entryFromWatchlist:
            self.entrySectionId = self.video.getLibrarySectionId()
            self.entryFromWatchlist = self.fromWatchlist or self.directlyFromWatchlist

        self.videos = None
        self.exitCommand = None
        self.trailer = None
        self.lastFocusID = None
        self.initialized = False
        self.relatedPaginator = None
        self.collectionPaginators = [None, None, None]
        self.openedWithAutoPlay = False
        self.fromPlayback = False
        self.useBGM = False
        # hashed-orbiting-pizza.md Phase 2: None here means "build my own sectionList" (a
        # standalone/un-hosted open) - a hosted open (LibraryWindow._setupCurrent(), library.py)
        # overwrites this with the host's own sectionList object before onFirstInit() runs.
        self.sectionList = None
        # (row list id, position) to focus once that row is filled, instead of Play: Back from a
        # screen this one opened (RowRestoreMixin).
        self.restoreFocus = kwargs.get('restore_focus')

    def restoreRows(self):
        """The rows Back returns focus to (RowRestoreMixin), by list id: the ones that open a screen
        in this one's place - a cast member, a related title, another film in the collection (on
        request, 2026-10-07). Not Extras: they play on top of this screen, which keeps its focus;
        nor Reviews, which open nothing."""
        rows = {self.ROLES_LIST_ID: self.rolesListControl,
                self.RELATED_LIST_ID: self.relatedListControl}
        rows.update(zip(self.COLLECTION_LIST_IDS, self.collectionListControls))
        return rows

    def asyncRestoreRows(self):
        # All of them: setup()'s batch_simple() fills every row on a worker.
        return tuple(self.restoreRows())

    def restoreDefaultFocusIds(self):
        # Play or Resume, or a watchlist screen's own buttons (watchlistItemAvailable()).
        return ((0, self.PLAY_BUTTON_ID, self.RESUME_BUTTON_ID) + tuple(self.WL_RELEVANT_BTNS) +
                tuple(self.WL_BTN_STATE_BTNS))

    def doClose(self, **kw):
        self.relatedPaginator = None
        # Kodi reuses native window IDs (kodigui.py's windowSetBackground() has its own,
        # longer-standing comment on this - "window ids get reused... may just be leftover from
        # whatever window last held this id"), and hashed-orbiting-pizza.md's Phase 4 host
        # mechanism reconstructs a fresh PrePlayWindow far more often/tightly than the old
        # real-nested-window-per-click design did. Live-confirmed: without this, the *next*
        # PrePlayWindow to reuse this window ID briefly shows this movie's hero art (the
        # window-level background property, which persists independently of
        # this Python object) until its own onFirstInit() gets far enough to overwrite it.
        # Clearing it here, on the way out - while self._winID is still correctly this
        # instance's own (must run before kodigui.ControlledWindow.doClose() below sets
        # self._closing, which makes setProperty() a no-op) - can't fully eliminate the gap (the
        # next instance still needs to load its own art), but replaces "briefly shows the wrong
        # movie" with "briefly shows nothing," which is what actually needs verifying live.
        self.setProperty('background', '')
        TasksMixin.doClose(self)
        kodigui.ControlledWindow.doClose(self)

    def backgroundItem(self):
        return self.video

    def onFirstInit(self):
        timing = kodigui.StepTiming('Pre-play open')
        if not self.fromWatchlist:
            # pre_play-wl.xml replaces this whole block with wl_availability.xml.tpl's own controls -
            # these ids only exist on the non-watchlist streams block
            self.initMediaInfoPillControls()

        self.extraListControl = kodigui.ManagedControlList(self, self.EXTRA_LIST_ID, 5)
        self.relatedListControl = kodigui.ManagedControlList(self, self.RELATED_LIST_ID, 5)
        self.rolesListControl = kodigui.ManagedControlList(self, self.ROLES_LIST_ID, 5)
        self.reviewsListControl = kodigui.ManagedControlList(self, self.REVIEWS_LIST_ID, 5)
        self.collectionListControls = [kodigui.ManagedControlList(self, lid, 5) for lid in self.COLLECTION_LIST_IDS]
        self.setBoolProperty("is_watchlisted", self.is_watchlisted)

        if self.sectionList is None:
            self.sectionList = kodigui.ManagedControlList(self, self.SECTION_LIST_ID, 15)
            self.buildSectionList()
        else:
            self.sectionList.newControl(self)
        self._selectActiveSection()
        self.displayServerAndUser()
        timing.mark('controls')

        self.setup(timing=timing)
        self.initialized = True

        if not util.getSetting("slow_connection") and not self.openedWithAutoPlay:
            self.themeMusicInit(self.video, locations=[os.path.dirname(s.part.file) for s in self.video.videoStreams])
        timing.mark('theme music')
        timing.log()

    def doAutoPlay(self, blind=False):
        # First reload the video to get all the other info
        self.video.reload(checkFiles=1, **VIDEO_RELOAD_KW)
        self.openedWithAutoPlay = True
        return self.playVideo(from_auto_play=True)

    @busy.dialog()
    def onReInit(self):
        PlaybackBtnMixin.onReInit(self)
        self.themeMusicReinit(self.video)
        self.initialized = False
        if util.getSetting("slow_connection"):
            self.setProperty('remainingTime', T(32914, "Loading"))
        if self.fromPlayback:
            # the stop's timeline report first: the server decides what was watched from it
            plexapp.util.APP.nowplayingmanager.waitForTimelines(2.0)
        self.video.reload(checkFiles=1, fromMediaChoice=self.video.mediaChoice is not None, skip_cache=True, **VIDEO_RELOAD_KW)
        # its watchlisted state is asked for below
        self.watchlist_reinit(self.video)
        removed_from_wl = False
        if self.fromPlayback:
            removed_from_wl = self.wl_auto_remove(self.video)
        self.fromPlayback = False
        self.refreshInfo(from_reinit=True)

        if not removed_from_wl:
            self.checkIsWatchlisted(self.video)
        self.initialized = True

    def onBlindClose(self):
        if self.fromPlayback and self.openedWithAutoPlay and not self.started:
            self.video.reload(checkFiles=1, fromMediaChoice=self.video.mediaChoice is not None, **VIDEO_RELOAD_KW)
            autoRemoveFromWatchlistBlind(self.video)

    def refreshInfo(self, from_reinit=False):
        oldFocusId = self.getFocusId()

        # skip setting background when coming from reinit (other window) if we've focused something other than
        # the button row's Play/Resume/Restart/Trailer/Info/More
        self.setInfo(skip_bg=from_reinit and oldFocusId not in (
            self.PLAY_BUTTON_ID, self.RESUME_BUTTON_ID, self.RESTART_BUTTON_ID, self.TRAILER_BUTTON_ID,
            self.INFO_BUTTON_ID, self.OPTIONS_BUTTON_ID))

        if not from_reinit:
            show_reviews = util.getSetting('show_reviews1')
            if show_reviews:
                if "watched" in show_reviews and "unwatched" not in show_reviews:
                    self.fillReviews()

            self.fillRelated()
        xbmc.sleep(100)

        # Any of the three play states, not just Play: which one was focused before the reload isn't
        # necessarily the one that should be focused after it (a resumed-then-finished video flips
        # from Resume/Restart back to Play), so focusPlayButton() re-picks by the current state.
        if oldFocusId in (self.PLAY_BUTTON_ID, self.RESUME_BUTTON_ID, self.RESTART_BUTTON_ID):
            self.focusPlayButton()

    def handleBack(self):
        return self.backToRowStartOrRetract()

    def backResetRows(self):
        rows = {self.ROLES_LIST_ID: self.rolesListControl,
                self.REVIEWS_LIST_ID: self.reviewsListControl,
                self.EXTRA_LIST_ID: self.extraListControl,
                self.RELATED_LIST_ID: self.relatedListControl}
        rows.update(zip(self.COLLECTION_LIST_IDS, self.collectionListControls))
        return rows

    def onAction(self, action):
        # Hosted: the host sees the action first (kodigui.BaseWindow.routeActionToHost()).
        if self.routeActionToHost(action):
            return
        try:
            controlID = self.getFocusId()

            if not controlID and self.lastFocusID and not action == xbmcgui.ACTION_MOUSE_MOVE:
                self.setFocusId(self.lastFocusID)

            if action == xbmcgui.ACTION_CONTEXT_MENU:
                # Swallowed on anything without a context menu of its own, rather than shoving focus
                # into OPTIONS_GROUP_ID (the header, group 200) the way this used to. That jump was
                # written when the header still carried the home/search buttons; every screen here now
                # blanks header_topleft in favour of the sidebar, so group 200's own
                # <defaultcontrol always="true">201</defaultcontrol> (default.xml.tpl) points at a
                # control that no longer exists. What's left inside it is the audio widget (204, only
                # focusable while Player.HasAudio) and, on Seasons/Episodes, the season tabs (205,
                # only when they have items) - so with nothing playing and no tabs the group has no
                # focusable child at all, Kodi drops focus entirely and the screen goes dead to
                # everything but Back (live-reported on Artist, Pre-play and skipChildren Seasons;
                # where tabs did exist the same jump landed focus on the tab bar instead).
                # Nothing is exempt here any more: in-progress items get their own Resume/Restart
                # buttons instead of a single Play, so the old "menu on Play forces the
                # resume-or-restart dropdown" shortcut (force_resume_menu) had nothing left to offer
                # and is gone - Play is inert under menu, on request.
                return

            elif action == xbmcgui.ACTION_NAV_BACK:
                if self.handleBack():
                    return

            elif self.isWatchedAction(action) and xbmc.getCondVisibility('ControlGroup({}).HasFocus(0)'.format(self.MAIN_BUTTON_GROUP_ID)):
                self.toggleWatched(self.video)
                return

            elif action == xbmcgui.ACTION_LAST_PAGE and xbmc.getCondVisibility('ControlGroup({}).HasFocus(0)'.format(self.MAIN_BUTTON_GROUP_ID)):
                next(self)
            elif action == xbmcgui.ACTION_NEXT_ITEM:
                self.setFocusId(300)
                next(self)
            elif action == xbmcgui.ACTION_FIRST_PAGE and xbmc.getCondVisibility('ControlGroup({}).HasFocus(0)'.format(self.MAIN_BUTTON_GROUP_ID)):
                self.prev()
            elif action == xbmcgui.ACTION_PREV_ITEM:
                self.setFocusId(300)
                self.prev()

            elif action == xbmcgui.ACTION_MOVE_UP and controlID in (self.REVIEWS_LIST_ID,
                                                                    self.ROLES_LIST_ID,
                                                                    self.EXTRA_LIST_ID):
                self.updateBackgroundFrom(self.video)

            if controlID == self.RELATED_LIST_ID:
                if self.relatedPaginator and self.relatedPaginator.boundaryHit:
                    self.relatedPaginator.paginate()
                    return

            if controlID in self.COLLECTION_LIST_IDS:
                idx = self.COLLECTION_LIST_IDS.index(controlID)
                paginator = self.collectionPaginators[idx]
                if paginator and paginator.boundaryHit:
                    paginator.paginate()
                    return
        except:
            util.ERROR()

        kodigui.ControlledWindow.onAction(self, action)

    def onClick(self, controlID):
        # Not live on its host yet, or any more (kodigui.BaseWindow.ignoresInput()).
        # Hosted: the host handles the sidebar's clicks (kodigui.BaseWindow.routeClickToHost()).
        if self.routeClickToHost(controlID):
            return
        if controlID == self.SECTION_LIST_ID:
            self.sectionClicked()
        elif controlID == self.EXTRA_LIST_ID:
            self.openItem(self.extraListControl)
        elif controlID == self.RELATED_LIST_ID:
            if pagination.isMoreSelected(self.relatedListControl):
                self.seeMoreRow(self.video.relatedKey(), self.getProperty('related.header'), self.relatedListControl)
            else:
                self.openItem(self.relatedListControl)
        elif controlID in self.COLLECTION_LIST_IDS:
            idx = self.COLLECTION_LIST_IDS.index(controlID)
            control = self.collectionListControls[idx]
            paginator = self.collectionPaginators[idx]
            if pagination.isMoreSelected(control) and paginator:
                self.seeMoreRow(paginator._path, self.getProperty('collection.header.{0}'.format(idx)), control)
            else:
                self.openItem(control)
        elif controlID == self.ROLES_LIST_ID:
            if not self.roleClicked():
                return
        elif controlID == self.PLAY_BUTTON_ID:
            self.playVideo()
        elif controlID == self.RESUME_BUTTON_ID:
            self.playVideo()
        elif controlID == self.RESTART_BUTTON_ID:
            self.playVideo(start_over=True)
        elif controlID in self.WL_RELEVANT_BTNS and self.fromWatchlist and self.wl_availability:
            self.wl_item_opener(self.video, self.openItem)
        elif controlID in self.WL_BTN_STATE_BTNS:
            is_watchlisted = self.toggleWatchlist(self.video)
            self.waitAndSetFocus(self.WL_BTN_STATE_WATCHLISTED if is_watchlisted else self.WL_BTN_STATE_NOT_WATCHLISTED)
        elif controlID == self.PLAYER_STATUS_BUTTON_ID:
            self.showAudioPlayer()
        elif controlID == self.INFO_BUTTON_ID:
            self.infoButtonClicked()
        elif controlID == self.SUMMARY_BUTTON_ID:
            self.summaryButtonClicked()
        elif controlID == self.TRAILER_BUTTON_ID:
            self.openItem(item=self.trailer)
        elif controlID == self.OPTIONS_BUTTON_ID:
            self.moreButtonClicked()

    def onFocus(self, controlID):
        # Not live on its host yet, or any more (kodigui.BaseWindow.ignoresInput()).
        # first, whether or not this is live yet: the sidebar rows read it (SidebarMixin)
        self.trackSidebarFocus(controlID)
        if self.ignoresInput():
            return
        self.reselectActiveSection(controlID, self.lastFocusID)
        self.lastFocusID = controlID

        if 399 < controlID < 500:
            self.setProperty('hub.focus', str(controlID - 400))
            self.setProperty('row.focused', '1')
        else:
            # row.focused (not hub.focus, which is never cleared once set - other controls key off
            # it staying "seen at least once") drives default_background.xml.tpl's scroll-dim scrim,
            # which needs to toggle back off when focus returns to the details/button area above the
            # row list.
            self.setProperty('row.focused', '')

        # SUMMARY_BUTTON_ID needs the same exclusion as ControlGroup(300)'s own focus below: it's a
        # header control that happens to live inside group 50 but outside group 300, so without this
        # the elif below misread focusing it as "focus moved into deeper content" and slid the whole
        # header up - same bug/fix as ShowWindow.onFocus()'s own copy of this (subitems.py), which
        # this was ported from.
        if (controlID == self.SUMMARY_BUTTON_ID or
                xbmc.getCondVisibility('ControlGroup(50).HasFocus(0) + ControlGroup(300).HasFocus(0)')):
            self.setProperty('on.extras', '')
        elif xbmc.getCondVisibility('ControlGroup(50).HasFocus(0) + !ControlGroup(300).HasFocus(0)'):
            self.setProperty('on.extras', '1')

    def toggleWatched(self, item, state=None, **kw):
        watched = super(PrePlayWindow, self).toggleWatched(item, state=state, **kw)
        if watched is None:
            return

        if watched:
            self.wl_auto_remove(self.video)
            self.checkIsWatchlisted(self.video)
        self.refreshInfo()
        util.MONITOR.watchStatusChanged()

    def roleSectionId(self):
        return self.entrySectionId

    def roleFromWatchlist(self):
        return self.entryFromWatchlist

    @kodigui.releasesDialogDim
    def moreButtonClicked(self):
        """More: the More settings dialog - the media settings (Video, Audio, Subtitles, Quality) with this
        screen's own actions under them (moreActions()), run once it's closed (runMoreAction())."""
        if not self.video.mediaChoice:
            playerObject = plexplayer.PlexPlayer(self.video)
            playerObject.build()
        choice = playersettings.showDialog(video=self.video, non_playback=True, heading=T(35200, 'More settings'),
                                           actions=self.moreActions())
        # The dialog's own Video entry (playersettings.showVideoDialog()) can change mediaChoice
        # itself - the video pill's own visible text is driven by the video.res/video.rendering
        # *properties* (media_info_pills.xml.tpl's label markup), separate from video_text below
        # (only ever used for the pill's width, via setAudioAndSubtitleInfo() ->
        # resizeMediaInfoPills()). Without refreshing these two properties here too, the pill kept
        # showing the previous version's resolution/codec even though the underlying media had
        # actually switched (live-reported) - setInfo() sets them the same way on a full refresh,
        # this is just that same pair repeated for this narrower post-dialog case.
        res = self.video.resolutionString()
        rendering = self.video.videoCodecRendering
        self.setProperty('video.res', res)
        self.setProperty('video.rendering', rendering)
        video_text = u'{0} {1}'.format(res, rendering) if rendering else res
        self.setAudioAndSubtitleInfo(video_text)
        if choice:
            self.runMoreAction(choice)

    def infoButtonClicked(self):
        # Popup, not opener.handleOpen(info.InfoWindow, ...) any more - same change episodes.py's
        # own Info button already got (infoButtonClicked() there):
        # title/subtitle/thumb/summary all duplicate what's already visible on this screen itself,
        # only the media/file/stream detail block (formatMediaDetails() - info.py, shared with
        # InfoWindow's own getVideoInfo()) was actually new information. A dialog like Settings'/
        # More's own popups, not a full window transition, so no cameFrom bookkeeping needed either
        # (that existed only for InfoWindow's own close-and-return-to-this-window flow).
        info.showMediaDetails(self.video)

    def summaryButtonClicked(self):
        info.showSummary(self.video.title, self.video.summary)

    def moreActions(self):
        """This screen's actions for the More settings dialog, [(key, label)] (runMoreAction() runs them). Marking
        and Delete ask over it, (key, label, question): Yes closes it on the action, run already confirmed."""
        options = []

        inProgress = self.video.viewOffset.asInt()
        if not self.video.isWatched or inProgress:
            options.append(('mark_watched', T(32319, 'Mark Played'), lambda: self.confirmWatched(True)))
        if self.video.isWatched or inProgress:
            options.append(('mark_unwatched', T(32318, 'Mark Unplayed'), lambda: self.confirmWatched(False)))

        if self.video.type == 'episode':
            options.append(('to_season', T(32400, 'Go to Season')))
            options.append(('to_show', T(32323, 'Go to Show')))

        if self.video.type in ('episode', 'movie'):
            options.append(('to_section', T(32324, u'Go to {0}').format(self.video.getLibrarySectionTitle())))

        if plexapp.ACCOUNT.isAdmin and self.video.server.owned:
            options.append(('refresh', T(33719, 'Refresh metadata')))

            if self.video.server.allowsMediaDeletion:
                # in a muted red, set apart from the rest as the one that can't be undone
                options.append(('delete', u'[COLOR FFD45B55]{0}[/COLOR]'.format(T(32322, 'Delete')),
                                lambda: optionsdialog.confirmDelete(self.video)))

        if 'items' in util.getSetting('cache_requests'):
            options.append(('cache_reset', T(33728, "Clear cache for item")))
        # Delete last, wherever it was added (sorted() keeps the rest in order)
        return sorted(options, key=lambda o: o[0] == 'delete')

    def runMoreAction(self, key):
        if key == 'mark_watched':
            self.toggleWatched(self.video, state=True, confirmed=True, **VIDEO_RELOAD_KW)
        elif key == 'mark_unwatched':
            self.toggleWatched(self.video, state=False, confirmed=True, **VIDEO_RELOAD_KW)
        elif key == 'to_season':
            self.processCommand(opener.open(self.video.parentRatingKey, context=self, server=self.video.server,
                                            entry_section_id=self.entrySectionId,
                                            entry_from_watchlist=self.entryFromWatchlist))
        elif key == 'to_show':
            self.processCommand(opener.open(self.video.grandparentRatingKey, context=self, server=self.video.server,
                                            entry_section_id=self.entrySectionId,
                                            entry_from_watchlist=self.entryFromWatchlist))
        elif key == 'to_section':
            self.cameFrom = "library"
            section = plexlibrary.LibrarySection.fromFilter(self.video)
            self.processCommand(opener.sectionClicked(section, context=self,
                                                      came_from=self.video.ratingKey)
                                )
        elif key == 'delete':
            self.delete(confirmed=True)
        elif key == 'refresh':
            self.video.refresh()
            self.video.reload(checkFiles=1, **VIDEO_RELOAD_KW)
            self.refreshInfo()
        elif key == "cache_reset":
            try:
                util.DEBUG_LOG('Clearing requests cache for {}...', self.video)
                self.video.clearCache()
                self.video.reload(checkFiles=1, **VIDEO_RELOAD_KW)
                self.refreshInfo()
            except Exception as e:
                util.DEBUG_LOG("Couldn't clear cache: {}", e)

    def delete(self, confirmed=False):
        """confirmed: asked already (More settings asks over itself, then runs this once it's closed)."""
        if not confirmed and not optionsdialog.confirmDelete(self.video):
            return

        if self._delete():
            self.doClose()
        else:
            util.messageDialog(T(32330, 'Message'), T(32331, 'There was a problem while attempting to delete the media.'))

    @busy.dialog()
    def _delete(self):
        success = self.video.delete()
        util.LOG('Media DELETE: {0} - {1}', self.video, success and 'SUCCESS' or 'FAILED')
        return success

    def getVideos(self):
        if not self.videos:
            if self.video.TYPE == 'episode':
                self.videos = self.video.show().episodes()

        if not self.videos:
            return False

        return True

    def next(self):
        if not self._next():
            return
        self.setup()

    __next__ = next

    @busy.dialog()
    def _next(self):
        if self.parentList:
            mli = self.parentList.getListItemByDataSource(self.video)
            if not mli:
                return False

            pos = mli.pos() + 1
            if not self.parentList.positionIsValid(pos):
                pos = 0

            self.video = self.parentList.getListItem(pos).dataSource
        else:
            if not self.getVideos():
                return False

            if self.video not in self.videos:
                return False

            pos = self.videos.index(self.video)
            pos += 1
            if pos >= len(self.videos):
                pos = 0

            self.video = self.videos[pos]

        return True

    def prev(self):
        if not self._prev():
            return
        self.setup()

    @busy.dialog()
    def _prev(self):
        if self.parentList:
            mli = self.parentList.getListItemByDataSource(self.video)
            if not mli:
                return False

            pos = mli.pos() - 1
            if pos < 0:
                pos = self.parentList.size() - 1

            self.video = self.parentList.getListItem(pos).dataSource
        else:
            if not self.getVideos():
                return False

            if self.video not in self.videos:
                return False

            pos = self.videos.index(self.video)
            pos -= 1
            if pos < 0:
                pos = len(self.videos) - 1

            self.video = self.videos[pos]

        return True

    def playVideo(self, from_auto_play=False, start_over=False):
        if self.playBtnClicked:
            return

        if not self.video.available():
            util.messageDialog(T(32312, 'Unavailable'), T(32313, 'This item is currently unavailable.'))
            return

        # A video with a resume point resumes - Resume, Play, or auto-play from a hub's "Resume from" - unless
        # start_over (the Restart button's) or self.startOver (the same, carried in from whoever opened this
        # window: a hub's "Play from beginning") asks for its beginning.
        resume = bool(self.video.viewOffset.asInt()) and not self.startOver and not start_over

        if not from_auto_play:
            self.playBtnClicked = True

        self.fromPlayback = True

        preRoll = util.getUserSetting('preplay_preroll', False)
        preRollFirst = util.getUserSetting('preplay_preroll_first', True)
        trailers = 5 - util.getUserSetting('preplay_trailers', 5)
        # play playqueue if necessary (trailer preplay or plex told us to preplay something)
        if not resume:
            if preRoll or trailers:
                pq = playqueue.createPlayQueueForItem(self.video, use_async=False, method="POST",
                                                          extrasPrefixCount=trailers)

                _items = [item for item in pq.items if item.get('type') == 'clip']
                for item in _items:
                    item.isExtra = True

                if preRoll and preRollFirst and trailers:
                    items = []
                    # move prerolls to the front
                    for item in reversed(_items):
                        if not item.get('subtype'):
                            # pre-roll detected
                            items.insert(0, item)
                    for item in _items:
                        if item.get('subtype') == 'trailer':
                            items.append(item)
                else:
                    # use server pq as is, but filter out prerolls if not wanted
                    items = list(filter(lambda x: x.get('subtype') == "trailer", _items)) if not preRoll else _items

                items.append(self.video)

                pl = playlist.LocalPlaylist(items, self.video.getServer())
                self.processCommand(
                    videoplayer.play(play_queue=pl, bgm=self.useBGM, context=self))
                return True

        self.processCommand(videoplayer.play(video=self.video, resume=resume, bgm=self.useBGM, context=self))
        return True

    def openItem(self, control=None, item=None, inherit_from_watchlist=True, server=None, is_watchlisted=False, **kw):
        if not item:
            mli = control.getSelectedItem()
            if not mli:
                return
            item = mli.dataSource

        self.processCommand(opener.open(item, context=self,
                                        from_watchlist=self.fromWatchlist if inherit_from_watchlist else False,
                                        server=server, is_watchlisted=is_watchlisted,
                                        entry_section_id=self.entrySectionId,
                                        entry_from_watchlist=self.entryFromWatchlist, **kw))

    def focusPlayButton(self, extended=False):
        if extended:
            self.setFocusId(self.wl_play_button_id)
            return
        # Resume, not Play, for a part-watched video: Play is hidden in that state (in.progress -
        # setInfo()), and focusing a hidden control would just fall through to whatever Kodi picks
        # next, exactly what the wait below exists to prevent.
        button_id = self.RESUME_BUTTON_ID if self.getProperty('in.progress') else self.PLAY_BUTTON_ID
        try:
            if not self.getFocusId() == button_id:
                # the button's own <visible> (unavailable/disable_playback/in.progress) is keyed off
                # properties we just set, but the GUI thread hasn't necessarily recalculated
                # visibility yet - SetFocus on a still-invisible control fails silently and focus
                # falls through elsewhere (e.g. a hub row, which then triggers its slide-into-view
                # animation). Wait for it to actually be visible first.
                self.waitForVisibility(button_id)
                self.setFocusId(button_id)
        except (SystemError, RuntimeError):
            util.ERROR()
            self.setFocusId(button_id)

    @busy.dialog()
    def setup(self, timing=None):
        self.watchlist_setup(self.video)

        util.DEBUG_LOG('PrePlay: Showing video info: {0}', self.video)

        if self.isExternal:
            # fixme, multiple? choice?
            self.video.related_source = "more-from-credits"
        self.paintClickedItem()
        kodigui.markStep(timing, 'paint clicked')
        # a version chosen before opening (Search's Open from) kept, as onReInit() keeps one -
        # dropped if the reload no longer has it
        self.video.reload(checkFiles=1, fromMediaChoice=self.video.mediaChoice is not None, **VIDEO_RELOAD_KW)
        if self.video.mediaChoice is not None and self.video.mediaChoice.media is None:
            self.video.mediaChoice = None
        if self.video.reloadFailed:
            # Deleted, or the server's gone: setInfo() below reads fields only a full reload
            # fills, and raised a TypeError, leaving a half-painted screen that never finished
            # its init (live on the AM6B, 2026-09-27). The host goes back instead (viewClosed()).
            # A Watchlist item too (external_item), whose reload is plex.tv's: refused while
            # plex.tv was limiting requests, setInfo() crashed the same way (live 2026-10-05).
            if self.isExternal:
                util.notifyWatchlistUnavailable(getattr(self.video, 'reloadError', None))
            raise util.NoDataException
        kodigui.markStep(timing, 'reload')

        if self.fromWatchlist:
            self.watchlistItemAvailable(self.video, shortcut_watchlisted=self.directlyFromWatchlist)
        if not self.directlyFromWatchlist:
            self.checkIsWatchlisted(self.video)
        kodigui.markStep(timing, 'watchlist')

        self.setInfo()
        self.setBoolProperty("initialized", True)
        kodigui.markStep(timing, 'setInfo')
        # For watchlist items, PLAY_BUTTON_ID is permanently hidden behind disable_playback
        # - watchlistItemAvailable() above already owns focusing the dynamic wl button (2302-2305)
        # once its availability check resolves, so waiting on Play here would just block on a
        # control that's never going to show up.
        if not self.fromWatchlist:
            self.focusPlayButton()
        elif not self.wl_enabled and self.getProperty('summary'):
            # the Watchlist off, there's no availability check to focus its button, and Discover's
            # item has no file for Info: the summary (a trailer's button comes with the extras)
            kodigui.waitForVisibility(self.SUMMARY_BUTTON_ID, amount=1)
            self.setFocusId(self.SUMMARY_BUTTON_ID)
        kodigui.markStep(timing, 'focus')
        # The row fills that can hold a Back restore are followed by it (RowRestoreMixin).
        self.batch_simple([(self._fillThenRestore(self.fillRoles, self.ROLES_LIST_ID), None, None),
                           (self.fillReviews, None, None),
                           (self.fillExtras, None, None),
                           (self._fillThenRestore(self.fillRelated, self.RELATED_LIST_ID), None, None),
                           (self._fillThenRestore(self.fillCollections, *self.COLLECTION_LIST_IDS), None, None)])

    def paintClickedItem(self):
        """Show what the clicked item already carries before the reload below blocks on the server
        (P4 in the navigation review: 280-575 ms on the AM6B). Kodi keeps rendering while this
        thread waits, so the title, logo and summary are up for that time instead of an empty
        screen. Plain attributes only - a hub or grid item isn't a full object, and genres(), for
        one, reloads it. setInfo() then writes everything from the full item; the buttons stay
        hidden until then (initialized)."""
        video = self.video
        # the bare title: a film's edition has its own pill on the meta row (pp_meta_row.xml.tpl), where
        # defaultTitle would add it here too ("Heat • Director's Cut")
        self.setProperty('title', video.title)
        self.setProperty('clear.logo', util.clearLogoFrom(video, *self.CLEAR_LOGO_DIM))
        self.setProperty('summary', util.summaryForBox(video.summary))
        self.setProperty('date', video.year)
        self.setProperty('duration', video.duration and util.durationToShortText(video.duration.asInt(), noSpaces=True))
        self.setProperty('content.rating', video.contentRating.split('/', 1)[-1])

    def setInfo(self, skip_bg=False):
        if not skip_bg:
            self.updateBackgroundFrom(self.video)
        self.setProperty('title', self.video.title)
        logo = util.clearLogoFrom(self.video, *self.CLEAR_LOGO_DIM)
        self.setProperty('clear.logo', logo)
        self.setProperty('duration', self.video.duration and util.durationToShortText(self.video.duration.asInt(), noSpaces=True))
        self.setProperty('summary', util.summaryForBox(self.video.summary))
        self.setProperty('unwatched', not self.video.isWatched and '1' or '')
        self.setBoolProperty('watched', self.video.isPlayed)
        self.setBoolProperty('disable_playback', self.fromWatchlist)

        # Drives the button row's Play -> Resume+Restart split (script-plex-pre_play.xml.tpl).
        # Unconditional, unlike the remainingTime property further down: that one lives in the
        # non-watchlist branch, but these two have to be actively cleared for a watchlist item too,
        # or a stale in.progress from a previous video would leave this row showing Resume/Restart
        # over a play button that disable_playback has already hidden.
        # Duration is required, not just the offset: the Resume label carries a time-left suffix
        # computed from it (resume.timeleft), and without one there'd be nothing to put after the
        # bullet. An item with an offset but no duration falls back to plain Play, which still
        # resumes it (playVideo()).
        view_offset = self.video.viewOffset.asInt()
        duration = self.video.duration.asInt()
        in_progress = bool(view_offset and duration) and not self.fromWatchlist
        self.setBoolProperty('in.progress', in_progress)
        # remainingTimeToShortText's own no-space, 90-minute-cutoff style ("1h31m left"), matching
        # Episodes' own Resume button - not remainingTime's spaced "1h 31m left" below.
        self.setProperty('resume.timeleft', in_progress and T(33615, "{time} left").format(
            time=util.remainingTimeToShortText(duration - view_offset)) or '')

        directors = u' / '.join([d.tag for d in self.video.directors()][:3])
        directorsLabel = len(self.video.directors) > 1 and T(32401, u'DIRECTORS').upper() or T(32383, u'DIRECTOR').upper()
        self.setProperty('directors', directors and u'{0}    {1}'.format(directorsLabel, directors) or '')
        writers = u' / '.join([r.tag for r in self.video.writers()][:3])
        writersLabel = len(self.video.writers) > 1 and T(32403, u'WRITERS').upper() or T(32402, u'WRITER').upper()
        self.setProperty('writers',
                         writers and u'{0}{1}    {2}'.format(directors and '    ' or '', writersLabel, writers) or '')

        # the bare title, as paintClickedItem()'s: the edition has its own pill
        self.setProperty('title', self.video.title)
        genres = u' / '.join([g.tag for g in self.video.genres()][:3])
        self.setProperty('info', genres)
        # Separate from 'info' above (used by the info/options dialogs elsewhere, 3 genres joined by
        # ' / ') - the metadata row (pp_meta_row.xml.tpl) wants its own shorter, comma-separated form.
        self.setProperty('genres.short', u', '.join([g.tag for g in self.video.genres()][:2]))
        self.setProperty('date', self.video.year)
        if self.fromWatchlist and not self.wl_availability:
            self.setProperty('wl_server_availability_verbose', util.cleanLeadingZeros(self.video.originallyAvailableAt.asDatetime('%B %d, %Y')))
        self.setProperty('content.rating', self.video.contentRating.split('/', 1)[-1])

        cast = u' / '.join([r.tag for r in self.video.roles()][:5])
        castLabel = 'CAST'
        self.setProperty('cast', cast and u'{0}    {1}'.format(castLabel, cast) or '')
        self.setProperty('related.header', T(32404, 'Related Movies') if not self.fromWatchlist else T(34018, 'Related Media'))

        if self.fromWatchlist:
            self.setProperty('studios', u' / '.join([r.tag for r in self.video.studios()][:2]))

        else:
            # single studio attribute here, vs. the joined tag list above, but both feed the same 'studios' property
            self.setProperty('studios', self.video.studio)
            self.setProperty('video.res', self.video.resolutionString())
            self.setProperty('audio.codec', self.video.audioCodecString())
            self.setProperty('video.codec', self.video.videoCodecString())
            self.setProperty('video.rendering', self.video.videoCodecRendering)
            self.setProperty('audio.channels', self.video.audioChannelsString(metadata.apiTranslate))

            video_text = self.video.resolutionString()
            if self.video.videoCodecRendering:
                video_text = u'{0} {1}'.format(video_text, self.video.videoCodecRendering)

        self.populateRatings(self.video, self)

        # The rest of the shared meta row (CommonMixin.META_ROW_PROPERTIES) this screen has no
        # value for; a Watchlist item has none for the two below either.
        self.blankMetaRow('episode.code')
        # a film's edition ("Director's Cut"), its own pill before the time left
        self.setProperty('edition', u'{0}'.format(getattr(self.video, 'editionTitle', None) or ''))
        if not self.fromWatchlist:
            self.setAudioAndSubtitleInfo(video_text)

            self.setProperty('unavailable', all(not v.isAccessible() for v in self.video.media()) and '1' or '')

            if self.video.viewOffset.asInt():
                self.setProperty('remainingTime', T(33615, "{time} left").format(time=self.video.remainingTimeString))
            else:
                self.setProperty('remainingTime', '')
        else:
            self.blankMetaRow('unavailable', 'remainingTime')

    def setAudioAndSubtitleInfo(self, video_text):
        # discover external audio files for mapped direct play
        if util.getSetting('use_external_audio', False) and hasattr(type(self.video), 'discoverExternalAudioStreams'):
            self.video.discoverExternalAudioStreams()

        sas = self.video.selectedAudioStream()

        audio_text = ''
        if sas:
            audio_text = sas.getTitle(metadata.apiTranslate)
            self.setProperty('audio', audio_text)

        sss = self.video.selectedSubtitleStream(
            forced_subtitles_override=util.getSetting("forced_subtitles_override") and pnUtil.ACCOUNT.subtitlesForced == 0,
            deselect_subtitles=getNativeLanguages(util.getSetting("disable_subtitle_languages") or []))
        if sss:
            subtitles_text = sss.getTitle(metadata.apiTranslate)
        elif self.video.subtitleStreams:
            subtitles_text = T(32481, 'Off')
        else:
            subtitles_text = T(32309, u'None')
        self.setProperty('subtitles', subtitles_text)

        self.resizeMediaInfoPills(video_text, audio_text, subtitles_text)

    def createListItem(self, obj):
        mli = kodigui.ManagedListItem(obj.title or '', thumbnailImage=obj.thumb.asTranscodedImageURL(*self.EXTRA_DIM), data_source=obj)
        return mli

    def fillExtras(self):
        items = []
        idx = 0

        if not self.video.extras:
            if self.fromWatchlist:
                self.video.fetchExternalExtras()

            if not self.video.extras:
                self.extraListControl.reset()
                return False

        for extra in self.video.extras:
            if not self.trailer and extra.extraType.asInt() == media.METADATA_RELATED_TRAILER:
                self.trailer = extra
                self.setProperty('trailer.button', '1')

            mli = self.createListItem(extra)
            if mli:
                mli.setProperty('index', str(idx))
                mli.setProperty(
                    'thumb.fallback', 'script.plex/thumb_fallbacks/{0}.png'.format(extra.type in ('show', 'season', 'episode') and 'show' or 'movie')
                )
                mli.setProperty('extra.duration', extra.duration and util.simplifiedTimeDisplay(extra.duration.asInt()))
                items.append(mli)
                idx += 1

        if not items:
            return False

        self.extraListControl.reset()
        self.extraListControl.addItems(items)

        return True

    def fillRelated(self):
        if self.tasks is None:
            # closed before this task ran
            return False
        if self.relatedPaginator is None:
            # Built here, on the fill's worker, not in setup(): sizing it is a server query (the
            # 'similar' count, ~250 ms on the AM6B) that held up every movie open (P4 in the
            # navigation review).
            try:
                count = int(self.video.relatedCount)
            except ValueError:
                count = 0
            cls = RelatedPaginator if self.fromWatchlist else RelatedRowPaginator
            self.relatedPaginator = cls(self.relatedListControl, leaf_count=count, parent_window=self)
        paginator = self.relatedPaginator
        if not paginator.leafCount:
            self.relatedListControl.reset()
            return False

        items = paginator.paginate()

        if not items:
            return False

        return True

    def fillCollections(self):
        section_id = self.video.getLibrarySectionId()
        # Both ways to a collection's listing below are in the film's library section, so none
        # without one: a Watchlist (Discover) film's every row 404'd on '/library/sections//all'.
        collections = self.video.collections() if (self.video.type == 'movie' and self.video.collections
                                                   and section_id) else []

        # Fetch the section's collection metadata items to get their proper keys,
        # which respect the sort order set in Plex (Custom / Alphabetical / Release Date).
        # The id on a movie's <Collection> tag is a tag ID, not a metadata ratingKey,
        # so we can't use it directly — match by title instead.
        col_key_map = {}  # title → key (e.g. "/library/metadata/12345/children")
        # Only when there's something to look up: most movies are in no collection, and a
        # watchlist (discover) item has no library section - '/library/sections//collections'
        # 404'd on every one of those.
        if collections and section_id:
            try:
                col_items = plexobjects.listItems(
                    self.video.server,
                    '/library/sections/{0}/collections'.format(section_id)
                )
                for col_item in col_items:
                    title = str(col_item.title)
                    key = str(col_item.key)
                    if title and key:
                        col_key_map[title] = key
            except Exception:
                util.ERROR()

        for i, list_control in enumerate(self.collectionListControls):
            if i >= len(collections):
                list_control.reset()
                self.setProperty('collection.header.{0}'.format(i), '')
                self.collectionPaginators[i] = None
                continue

            collection = collections[i]
            tag = str(collection.tag)
            if tag in col_key_map:
                path = col_key_map[tag]
            else:
                # Fallback: filter-based path. Works but ignores custom sort order.
                path = '/library/sections/{0}/all?type=1&{1}'.format(section_id, collection.filter)

            cls = CollectionPaginator if self.fromWatchlist else CollectionRowPaginator
            paginator = cls(list_control, parent_window=self, leaf_count=0)
            paginator.setup(self.video.server, path)
            try:
                paginator.paginate()
            except Exception:
                util.ERROR()
                list_control.reset()
                self.setProperty('collection.header.{0}'.format(i), '')
                self.collectionPaginators[i] = None
                continue

            self.collectionPaginators[i] = paginator
            self.setProperty('collection.header.{0}'.format(i), collection.tag)

    def seeMoreRow(self, key, title, control):
        """A Related or collection row's "See more": its whole list, key, in the poster grid
        (see_more.openRowGrid())."""
        from . import see_more
        see_more.openRowGrid(self, self.video.server, key, title, control)

    def creditsItem(self):
        return self.video

    def fillRoles(self):
        return self.fillCreditsRow()

    def fillReviews(self):
        items = []
        idx = 0

        show_reviews = util.getSetting('show_reviews1')
        fully_watched = self.video.isFullyWatched

        if (not show_reviews or not self.video.reviews or
                ("unwatched" not in show_reviews and not fully_watched) or
                ("watched" not in show_reviews and fully_watched)):
            self.reviewsListControl.reset()
            return False

        for review in self.video.reviews():
            mli = kodigui.ManagedListItem(review.source, review.tag, thumbnailImage=review.ratingImage())
            mli.setProperty('index', str(idx))
            mli.setProperty('text', review.text)
            items.append(mli)
            idx += 1

        if not items:
            return False

        self.reviewsListControl.reset()
        self.reviewsListControl.addItems(items)
        return True

class PrePlayWindowWL(PrePlayWindow):
    xmlFile = 'script-plex-pre_play-wl.xml'
