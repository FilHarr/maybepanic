# coding=utf-8
from __future__ import absolute_import
import logging
import tempfile
import sys

from lib.logging import log, KodiLogProxyHandler
# noinspection PyUnresolvedReferences
from lib.kodi_util import translatePath, xbmc, xbmcgui, UPSTREAM_ADDON_ID
from lib.properties import getGlobalProperty, setGlobalProperty
from tendo_singleton import SingleInstance, SingleInstanceException

# tempfile's standard temp dirs won't work on specific OS's (android)
tempfile.tempdir = translatePath("special://temp/")

# add custom logger for tendo.singleton, so we can capture its messages
logger = logging.getLogger("tendo.singleton")
logger.addHandler(KodiLogProxyHandler(level=logging.DEBUG))
logger.setLevel(logging.DEBUG)


from_kiosk = False
kiosk_always = False
boot_delay = False
skip_ensure_last_used = False
argvlen = len(sys.argv)
if argvlen > 1:
    try:
        from_kiosk = int(sys.argv[1]) > 0
    except ValueError:
        # first arg can be "fromplugin" as well
        from_kiosk = False
        skip_ensure_last_used = True
    else:
        kiosk_always = int(sys.argv[1]) > 1
        if argvlen > 2:
            boot_delay = int(sys.argv[2])
            if argvlen > 3:
                update_successful = bool(int(sys.argv[3]))

started = False
set_waiting_for_start = False
try:
    # reactivate/maximize
    # 'running' is shared by every copy of the add-on (script.plex.* properties) and holds the running copy's
    # ID, so RESTORE goes to that copy, which may not be us. Versions before this set '1'.
    running = getGlobalProperty('running')
    if running:
        try:
            log('Main: {}: Trying to reactivate minimized addon', running)
            xbmc.executebuiltin('NotifyAll({0},{1},{2})'.format(
                running if running != '1' else UPSTREAM_ADDON_ID, 'RESTORE', '{}'))
        except:
            log('Main: script.plexmod: Already running or faulty, couldn\'t reactivate other instance, exiting.')
        else:
            sys.exit(0)
    else:
        # we're waiting for the addon to start, immediate start was requested - checked before 'started', which
        # the waiting copy has already claimed
        if getGlobalProperty('waiting_for_start'):
            setGlobalProperty('waiting_for_start', '', wait=True)
            log('Main: script.plexmod: Currently waiting for start, immediate start was requested.')
            sys.exit(0)

        # addon not started
        if not getGlobalProperty('started'):
            # Claimed at once, not once started: the import below and the auto-start waits take seconds on a slow
            # box, and a copy launched meanwhile (OK pressed as Kodi came up, with auto-start on) saw nothing set and
            # ran as well - two copies, each with its own windows (the user's AM6B, 2026-10-28). SingleInstance's
            # file lock can't tell: every add-on runs in Kodi's one process. finally clears it.
            setGlobalProperty('started', '1', wait=True)
            started = True

            # only allow a single instance
            with SingleInstance("pm4k"):
                skip_ensure_home = False
                from lib import main

                if skip_ensure_last_used:
                    # if we were called from out plugin endpoint, make sure not to try and stub-run the plugin endpoint
                    # again when exiting
                    main.skipEnsureLastUsed = True

                # called from service.py?
                if from_kiosk:
                    waited = 0
                    if boot_delay:
                        set_waiting_for_start = True
                        setGlobalProperty('waiting_for_start', '1', wait=True)
                        log('Main: script.plexmod: Delaying start for {}s.', boot_delay)
                        while (not main.util.MONITOR.abortRequested() and waited < main.util.MONITOR.waitAmount(boot_delay)
                               and getGlobalProperty('waiting_for_start')):
                            waited += 1
                            main.util.MONITOR.waitFor()

                    # boot delay canceled by immediate start
                    if waited < boot_delay:
                        log('Main: script.plexmod: Forced start before auto-start delay ({:.1f}/{} s).',
                            waited, boot_delay)
                        skip_ensure_home = True

                    if kiosk_always:
                        skip_ensure_home = True

                    waited = 0
                    # wait 120s if we're not at home right now or have an active dialog until starting the addon
                    if not skip_ensure_home and \
                            (xbmcgui.getCurrentWindowId() > 10000 or xbmcgui.getCurrentWindowDialogId() > 9999):
                        setGlobalProperty('waiting_for_start', '1', wait=True)

                        while getGlobalProperty('waiting_for_start') and not main.util.MONITOR.abortRequested() and \
                                waited < 120 and (
                                xbmcgui.getCurrentWindowId() > 10000 or xbmcgui.getCurrentWindowDialogId() > 9999):
                            if waited == 0:
                                log('Main: script.plexmod: Waiting for auto-start; we\'re not home or have an '
                                    'active dialog.')
                            waited += 0.1
                            main.util.MONITOR.waitForAbort(0.1)

                        if from_kiosk:
                            # no immediate start requested
                            main.util.MONITOR.waitForAbort(0.5)

                setGlobalProperty('waiting_for_start', '', wait=True)

                main.main()
        else:
            log('Main: script.plexmod: Already running, exiting')

except SingleInstanceException:
    pass

except SystemExit as e:
    if e.code not in (-1, 0):
        raise

finally:
    if started:
        setGlobalProperty('started', '')
    if set_waiting_for_start:
        setGlobalProperty('waiting_for_start', '')
