# coding=utf-8
from lib.settings_util import getSetting


class AddonSettings(object):
    """
    @DynamicAttrs
    """

    _proxiedSettings = (
        ("debug", False),
        ("debug_requests", False),
        ("kodi_skip_stepping", False),
        ("auto_seek", True),
        # a float: the default's type is what the value's read as, and an int truncated the slider's 0.1 steps
        ("auto_seek_delay", 1.0),
        ("fast_back", True),
        ("dynamic_backgrounds", True),
        ("screensaver_quiz", False),
        ("skip_intro_button_timeout", 10),
        ("skip_credits_button_timeout", 10),
        ("playlist_visit_media", False),
        ("show_media_ends_info", True),
        ("show_media_ends_label", True),
        ("background_colour", None),
        ("custom_background_colour", None),
        ("skip_intro_button_show_early_threshold2", 120),
        ("requests_timeout_connect", 5.0),
        ("requests_timeout_read", 5.0),
        ("plextv_timeout_connect", 1.0),
        ("plextv_timeout_read", 2.0),
        ("local_reach_timeout", 10),
        ("auto_skip_offset", 1.0),
        ("conn_check_timeout", 2.5),
        ("skip_marker_timer_cancel", True),
        ("skip_marker_timer_immediate", False),
        ("player_show_buffer", True),
        ("buffer_wait_max", 120),
        ("buffer_insufficient_wait", 10),
        ("dbg_crossfade", True),
        ("subtitle_use_extended_title", True),
        ("poster_resolution_scale_perc", 100),
        ("consecutive_video_pb_wait", 0.0),
        ("verify_mapped_files", True),
        ("episode_no_spoiler_blur", 16),
        ("ignore_docker_v4", True),
        ("cache_home_users", True),
        ("intro_marker_max_offset", 1400),
        ("max_retries1", 3),
        ("use_cert_bundle", "acme"),
        ("cache_templates", True),
        ("always_compile_templates", False),
        ("tickrate", 1.0),
        ("honor_plextv_dnsrebind", True),
        ("honor_plextv_pam", True),
        ("coreelec_resume_seek_wait2", 100),
        ("altseek_valid_seek_window", 2000),
        ("background_resolution_scale_perc", 100),
        ("osd_hide_delay", 4.0),
        ("requests_cache_expiry", 72),
        ("playlist_max_size", 500),
        ("max_shutdown_wait", 5),
        ("unlock_res", False),
        ("ui_wait_rate", 10),
        ("theme_music_fade", True),
        ("cache_theme_music", True),
        ("coreelec_seek_prefer_reported", True),
        ("coreelec_wait_player_time1", True),
        ("seamless_branching_lav_mode", 4),
        ("seekbackonstart_delay", 500),
    )

    def __init__(self):
        # register every known setting camelCased as an attribute to this instance
        for setting, default in self._proxiedSettings:
            name_split = setting.split("_")
            setattr(self, name_split[0] + ''.join(x.capitalize() or '_' for x in name_split[1:]),
                    getSetting(setting, default))


addonSettings = AddonSettings()